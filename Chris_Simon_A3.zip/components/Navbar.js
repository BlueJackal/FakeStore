import { useState } from 'react';
import { useRouter } from 'next/router';
import { Navbar, Nav, Container, Form, FormControl, Button } from 'react-bootstrap';

export default function CustomNavbar() {
    const [searchTerm, setSearchTerm] = useState('');
    const router = useRouter();

    const handleSearch = (e) => {
        e.preventDefault();
        router.push(`/products?search=${encodeURIComponent(searchTerm)}`);
    };

    const handleNavigation = (e, path) => {
        e.preventDefault();
        router.push(path);
    };

    return (
        <Navbar bg="light" expand="lg">
            <Container>
                <Navbar.Brand href="/" onClick={(e) => handleNavigation(e, '/')}>
                    <img
                        src="/img/header_logo.png"
                        width="30"
                        height="30"
                        className="d-inline-block align-top"
                        alt="Logo"
                    />
                    {' '}
                    Chris Simon - Web Assignment 3
                </Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="me-auto">
                        <Nav.Link href="/" onClick={(e) => handleNavigation(e, '/')}>Home</Nav.Link>
                        <Nav.Link href="/about" onClick={(e) => handleNavigation(e, '/about')}>About</Nav.Link>
                        <Nav.Link href="/products" onClick={(e) => handleNavigation(e, '/products')}>Products</Nav.Link>
                    </Nav>
                    <Form className="d-flex" onSubmit={handleSearch}>
                        <FormControl
                            type="search"
                            placeholder="Search Products"
                            className="me-2"
                            aria-label="Search"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                        <Button variant="outline-success" type="submit">Search</Button>
                    </Form>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
}

import { Modal, Button, Image } from 'react-bootstrap';

export default function ProductModal({ show, handleClose, product }) {
    return (
        <Modal show={show} onHide={handleClose} centered>
            <Modal.Header closeButton>
                <Modal.Title>{product?.title}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Image src={product?.image} fluid />
                <p>{product?.description}</p>
                <h3>${product?.price}</h3>
                <p>Category: {product?.category}</p>
                <p>Rating: {product?.rating?.rate} ({product?.rating?.count} Reviews)</p>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                    Close
                </Button>
            </Modal.Footer>
        </Modal>
    );
}
/********************************************************************************
*  WEB422 – Assignment 3
*  
*  I declare that this assignment is my own work in accordance with Seneca's 
*  Academic Integrity Policy: 
*  
*  https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html 
*  
*  Name: Christopher Simon   Student ID: 123382228   Date: June 22nd, 2024
*
********************************************************************************/


import About from '../components/About';

export default function AboutPage() {
    return (
        <div>
            <About />
        </div>
    );
}

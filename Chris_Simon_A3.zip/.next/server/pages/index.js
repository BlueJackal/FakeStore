/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./styles/Carousel.module.css":
/*!************************************!*\
  !*** ./styles/Carousel.module.css ***!
  \************************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"carouselContainer\": \"Carousel_carouselContainer__9HhKe\",\n\t\"carousel\": \"Carousel_carousel__wcTDt\",\n\t\"carouselImage\": \"Carousel_carouselImage__W_E9t\",\n\t\"carouselCaption\": \"Carousel_carouselCaption__4qIeJ\",\n\t\"carousel-indicators\": \"Carousel_carousel-indicators__vVPgw\",\n\t\"active\": \"Carousel_active__SfxBJ\",\n\t\"productTitle\": \"Carousel_productTitle__LMa8Q\",\n\t\"productPrice\": \"Carousel_productPrice__goUk5\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvQ2Fyb3VzZWwubW9kdWxlLmNzcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2ViNDIyX2Fzc2lnbm1lbnRfMy8uL3N0eWxlcy9DYXJvdXNlbC5tb2R1bGUuY3NzP2MxZjEiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gRXhwb3J0c1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cdFwiY2Fyb3VzZWxDb250YWluZXJcIjogXCJDYXJvdXNlbF9jYXJvdXNlbENvbnRhaW5lcl9fOUhoS2VcIixcblx0XCJjYXJvdXNlbFwiOiBcIkNhcm91c2VsX2Nhcm91c2VsX193Y1REdFwiLFxuXHRcImNhcm91c2VsSW1hZ2VcIjogXCJDYXJvdXNlbF9jYXJvdXNlbEltYWdlX19XX0U5dFwiLFxuXHRcImNhcm91c2VsQ2FwdGlvblwiOiBcIkNhcm91c2VsX2Nhcm91c2VsQ2FwdGlvbl9fNHFJZUpcIixcblx0XCJjYXJvdXNlbC1pbmRpY2F0b3JzXCI6IFwiQ2Fyb3VzZWxfY2Fyb3VzZWwtaW5kaWNhdG9yc19fdlZQZ3dcIixcblx0XCJhY3RpdmVcIjogXCJDYXJvdXNlbF9hY3RpdmVfX1NmeEJKXCIsXG5cdFwicHJvZHVjdFRpdGxlXCI6IFwiQ2Fyb3VzZWxfcHJvZHVjdFRpdGxlX19MTWE4UVwiLFxuXHRcInByb2R1Y3RQcmljZVwiOiBcIkNhcm91c2VsX3Byb2R1Y3RQcmljZV9fZ29VazVcIlxufTtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./styles/Carousel.module.css\n");

/***/ }),

/***/ "./styles/Intro.module.css":
/*!*********************************!*\
  !*** ./styles/Intro.module.css ***!
  \*********************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"introContainer\": \"Intro_introContainer__AjClo\",\n\t\"introText\": \"Intro_introText__wcHzh\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvSW50cm8ubW9kdWxlLmNzcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2ViNDIyX2Fzc2lnbm1lbnRfMy8uL3N0eWxlcy9JbnRyby5tb2R1bGUuY3NzPzcyYjEiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gRXhwb3J0c1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cdFwiaW50cm9Db250YWluZXJcIjogXCJJbnRyb19pbnRyb0NvbnRhaW5lcl9fQWpDbG9cIixcblx0XCJpbnRyb1RleHRcIjogXCJJbnRyb19pbnRyb1RleHRfX3djSHpoXCJcbn07XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./styles/Intro.module.css\n");

/***/ }),

/***/ "./styles/RandomProducts.module.css":
/*!******************************************!*\
  !*** ./styles/RandomProducts.module.css ***!
  \******************************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"productsContainer\": \"RandomProducts_productsContainer__kllSd\",\n\t\"card\": \"RandomProducts_card__nKEwh\",\n\t\"card-title\": \"RandomProducts_card-title__aVp7A\",\n\t\"card-text\": \"RandomProducts_card-text__c71IB\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvUmFuZG9tUHJvZHVjdHMubW9kdWxlLmNzcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYjQyMl9hc3NpZ25tZW50XzMvLi9zdHlsZXMvUmFuZG9tUHJvZHVjdHMubW9kdWxlLmNzcz81ZWNkIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcInByb2R1Y3RzQ29udGFpbmVyXCI6IFwiUmFuZG9tUHJvZHVjdHNfcHJvZHVjdHNDb250YWluZXJfX2tsbFNkXCIsXG5cdFwiY2FyZFwiOiBcIlJhbmRvbVByb2R1Y3RzX2NhcmRfX25LRXdoXCIsXG5cdFwiY2FyZC10aXRsZVwiOiBcIlJhbmRvbVByb2R1Y3RzX2NhcmQtdGl0bGVfX2FWcDdBXCIsXG5cdFwiY2FyZC10ZXh0XCI6IFwiUmFuZG9tUHJvZHVjdHNfY2FyZC10ZXh0X19jNzFJQlwiXG59O1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./styles/RandomProducts.module.css\n");

/***/ }),

/***/ "__barrel_optimize__?names=Button,Container,Form,FormControl,Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js":
/*!****************************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Button,Container,Form,FormControl,Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js ***!
  \****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Button: () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Container: () => (/* reexport safe */ _Container__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Form: () => (/* reexport safe */ _Form__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   FormControl: () => (/* reexport safe */ _FormControl__WEBPACK_IMPORTED_MODULE_3__[\"default\"]),\n/* harmony export */   Nav: () => (/* reexport safe */ _Nav__WEBPACK_IMPORTED_MODULE_4__[\"default\"]),\n/* harmony export */   Navbar: () => (/* reexport safe */ _Navbar__WEBPACK_IMPORTED_MODULE_5__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ \"./node_modules/react-bootstrap/esm/Button.js\");\n/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Container */ \"./node_modules/react-bootstrap/esm/Container.js\");\n/* harmony import */ var _Form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Form */ \"./node_modules/react-bootstrap/esm/Form.js\");\n/* harmony import */ var _FormControl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./FormControl */ \"./node_modules/react-bootstrap/esm/FormControl.js\");\n/* harmony import */ var _Nav__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Nav */ \"./node_modules/react-bootstrap/esm/Nav.js\");\n/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Navbar */ \"./node_modules/react-bootstrap/esm/Navbar.js\");\n\n\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1CdXR0b24sQ29udGFpbmVyLEZvcm0sRm9ybUNvbnRyb2wsTmF2LE5hdmJhciE9IS4vbm9kZV9tb2R1bGVzL3JlYWN0LWJvb3RzdHJhcC9lc20vaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUM0QztBQUNNO0FBQ1Y7QUFDYztBQUNoQiIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYjQyMl9hc3NpZ25tZW50XzMvLi9ub2RlX21vZHVsZXMvcmVhY3QtYm9vdHN0cmFwL2VzbS9pbmRleC5qcz82NTZhIl0sInNvdXJjZXNDb250ZW50IjpbIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBCdXR0b24gfSBmcm9tIFwiLi9CdXR0b25cIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBDb250YWluZXIgfSBmcm9tIFwiLi9Db250YWluZXJcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBGb3JtIH0gZnJvbSBcIi4vRm9ybVwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEZvcm1Db250cm9sIH0gZnJvbSBcIi4vRm9ybUNvbnRyb2xcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBOYXYgfSBmcm9tIFwiLi9OYXZcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBOYXZiYXIgfSBmcm9tIFwiLi9OYXZiYXJcIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Button,Container,Form,FormControl,Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Button,Image,Modal!=!./node_modules/react-bootstrap/esm/index.js":
/*!**************************************************************************************************!*\
  !*** __barrel_optimize__?names=Button,Image,Modal!=!./node_modules/react-bootstrap/esm/index.js ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Button: () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Image: () => (/* reexport safe */ _Image__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Modal: () => (/* reexport safe */ _Modal__WEBPACK_IMPORTED_MODULE_2__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ \"./node_modules/react-bootstrap/esm/Button.js\");\n/* harmony import */ var _Image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Image */ \"./node_modules/react-bootstrap/esm/Image.js\");\n/* harmony import */ var _Modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Modal */ \"./node_modules/react-bootstrap/esm/Modal.js\");\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1CdXR0b24sSW1hZ2UsTW9kYWwhPSEuL25vZGVfbW9kdWxlcy9yZWFjdC1ib290c3RyYXAvZXNtL2luZGV4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFDNEM7QUFDRiIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYjQyMl9hc3NpZ25tZW50XzMvLi9ub2RlX21vZHVsZXMvcmVhY3QtYm9vdHN0cmFwL2VzbS9pbmRleC5qcz85MmU4Il0sInNvdXJjZXNDb250ZW50IjpbIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBCdXR0b24gfSBmcm9tIFwiLi9CdXR0b25cIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBJbWFnZSB9IGZyb20gXCIuL0ltYWdlXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTW9kYWwgfSBmcm9tIFwiLi9Nb2RhbFwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Button,Image,Modal!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Card,Col,Container,Row!=!./node_modules/react-bootstrap/esm/index.js":
/*!******************************************************************************************************!*\
  !*** __barrel_optimize__?names=Card,Col,Container,Row!=!./node_modules/react-bootstrap/esm/index.js ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Card: () => (/* reexport safe */ _Card__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Col: () => (/* reexport safe */ _Col__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Container: () => (/* reexport safe */ _Container__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   Row: () => (/* reexport safe */ _Row__WEBPACK_IMPORTED_MODULE_3__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Card__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Card */ \"./node_modules/react-bootstrap/esm/Card.js\");\n/* harmony import */ var _Col__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Col */ \"./node_modules/react-bootstrap/esm/Col.js\");\n/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Container */ \"./node_modules/react-bootstrap/esm/Container.js\");\n/* harmony import */ var _Row__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Row */ \"./node_modules/react-bootstrap/esm/Row.js\");\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1DYXJkLENvbCxDb250YWluZXIsUm93IT0hLi9ub2RlX21vZHVsZXMvcmVhY3QtYm9vdHN0cmFwL2VzbS9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFDd0M7QUFDRjtBQUNZIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2ViNDIyX2Fzc2lnbm1lbnRfMy8uL25vZGVfbW9kdWxlcy9yZWFjdC1ib290c3RyYXAvZXNtL2luZGV4LmpzPzNhMTIiXSwic291cmNlc0NvbnRlbnQiOlsiXG5leHBvcnQgeyBkZWZhdWx0IGFzIENhcmQgfSBmcm9tIFwiLi9DYXJkXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQ29sIH0gZnJvbSBcIi4vQ29sXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQ29udGFpbmVyIH0gZnJvbSBcIi4vQ29udGFpbmVyXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgUm93IH0gZnJvbSBcIi4vUm93XCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Card,Col,Container,Row!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Carousel,Container!=!./node_modules/react-bootstrap/esm/index.js":
/*!**************************************************************************************************!*\
  !*** __barrel_optimize__?names=Carousel,Container!=!./node_modules/react-bootstrap/esm/index.js ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Carousel: () => (/* reexport safe */ _Carousel__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Container: () => (/* reexport safe */ _Container__WEBPACK_IMPORTED_MODULE_1__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Carousel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Carousel */ \"./node_modules/react-bootstrap/esm/Carousel.js\");\n/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Container */ \"./node_modules/react-bootstrap/esm/Container.js\");\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1DYXJvdXNlbCxDb250YWluZXIhPSEuL25vZGVfbW9kdWxlcy9yZWFjdC1ib290c3RyYXAvZXNtL2luZGV4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQ2dEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2ViNDIyX2Fzc2lnbm1lbnRfMy8uL25vZGVfbW9kdWxlcy9yZWFjdC1ib290c3RyYXAvZXNtL2luZGV4LmpzPzI0MzAiXSwic291cmNlc0NvbnRlbnQiOlsiXG5leHBvcnQgeyBkZWZhdWx0IGFzIENhcm91c2VsIH0gZnJvbSBcIi4vQ2Fyb3VzZWxcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBDb250YWluZXIgfSBmcm9tIFwiLi9Db250YWluZXJcIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Carousel,Container!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js":
/*!*****************************************************************************************!*\
  !*** __barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Container: () => (/* reexport safe */ _Container__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Container */ "./node_modules/react-bootstrap/esm/Container.js");



/***/ }),

/***/ "./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D! ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),\n/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),\n/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),\n/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),\n/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),\n/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),\n/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),\n/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/pages/module.compiled */ \"./node_modules/next/dist/server/future/route-modules/pages/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! private-next-pages/_document */ \"./pages/_document.js\");\n/* harmony import */ var private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! private-next-pages/_app */ \"./pages/_app.js\");\n/* harmony import */ var _pages_index_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages\\index.js */ \"./pages/index.js\");\n\n\n\n// Import the app and document modules.\n\n\n// Import the userland code.\n\n// Re-export the component (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, \"default\"));\n// Re-export methods.\nconst getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, \"getStaticProps\");\nconst getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, \"getStaticPaths\");\nconst getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, \"getServerSideProps\");\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, \"config\");\nconst reportWebVitals = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, \"reportWebVitals\");\n// Re-export legacy methods.\nconst unstable_getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticProps\");\nconst unstable_getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticPaths\");\nconst unstable_getStaticParams = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticParams\");\nconst unstable_getServerProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getServerProps\");\nconst unstable_getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getServerSideProps\");\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES,\n        page: \"/index\",\n        pathname: \"/\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\"\n    },\n    components: {\n        App: private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__[\"default\"],\n        Document: private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__[\"default\"]\n    },\n    userland: _pages_index_js__WEBPACK_IMPORTED_MODULE_5__\n});\n\n//# sourceMappingURL=pages.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTJnBhZ2U9JTJGJnByZWZlcnJlZFJlZ2lvbj0mYWJzb2x1dGVQYWdlUGF0aD0uJTJGcGFnZXMlNUNpbmRleC5qcyZhYnNvbHV0ZUFwcFBhdGg9cHJpdmF0ZS1uZXh0LXBhZ2VzJTJGX2FwcCZhYnNvbHV0ZURvY3VtZW50UGF0aD1wcml2YXRlLW5leHQtcGFnZXMlMkZfZG9jdW1lbnQmbWlkZGxld2FyZUNvbmZpZ0Jhc2U2ND1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBK0Y7QUFDaEM7QUFDTDtBQUMxRDtBQUNvRDtBQUNWO0FBQzFDO0FBQzhDO0FBQzlDO0FBQ0EsaUVBQWUsd0VBQUssQ0FBQyw0Q0FBUSxZQUFZLEVBQUM7QUFDMUM7QUFDTyx1QkFBdUIsd0VBQUssQ0FBQyw0Q0FBUTtBQUNyQyx1QkFBdUIsd0VBQUssQ0FBQyw0Q0FBUTtBQUNyQywyQkFBMkIsd0VBQUssQ0FBQyw0Q0FBUTtBQUN6QyxlQUFlLHdFQUFLLENBQUMsNENBQVE7QUFDN0Isd0JBQXdCLHdFQUFLLENBQUMsNENBQVE7QUFDN0M7QUFDTyxnQ0FBZ0Msd0VBQUssQ0FBQyw0Q0FBUTtBQUM5QyxnQ0FBZ0Msd0VBQUssQ0FBQyw0Q0FBUTtBQUM5QyxpQ0FBaUMsd0VBQUssQ0FBQyw0Q0FBUTtBQUMvQyxnQ0FBZ0Msd0VBQUssQ0FBQyw0Q0FBUTtBQUM5QyxvQ0FBb0Msd0VBQUssQ0FBQyw0Q0FBUTtBQUN6RDtBQUNPLHdCQUF3Qix5R0FBZ0I7QUFDL0M7QUFDQSxjQUFjLHlFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxXQUFXO0FBQ1gsZ0JBQWdCO0FBQ2hCLEtBQUs7QUFDTCxZQUFZO0FBQ1osQ0FBQzs7QUFFRCIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYjQyMl9hc3NpZ25tZW50XzMvPzJjZTYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGFnZXNSb3V0ZU1vZHVsZSB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1tb2R1bGVzL3BhZ2VzL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IGhvaXN0IH0gZnJvbSBcIm5leHQvZGlzdC9idWlsZC90ZW1wbGF0ZXMvaGVscGVyc1wiO1xuLy8gSW1wb3J0IHRoZSBhcHAgYW5kIGRvY3VtZW50IG1vZHVsZXMuXG5pbXBvcnQgRG9jdW1lbnQgZnJvbSBcInByaXZhdGUtbmV4dC1wYWdlcy9fZG9jdW1lbnRcIjtcbmltcG9ydCBBcHAgZnJvbSBcInByaXZhdGUtbmV4dC1wYWdlcy9fYXBwXCI7XG4vLyBJbXBvcnQgdGhlIHVzZXJsYW5kIGNvZGUuXG5pbXBvcnQgKiBhcyB1c2VybGFuZCBmcm9tIFwiLi9wYWdlc1xcXFxpbmRleC5qc1wiO1xuLy8gUmUtZXhwb3J0IHRoZSBjb21wb25lbnQgKHNob3VsZCBiZSB0aGUgZGVmYXVsdCBleHBvcnQpLlxuZXhwb3J0IGRlZmF1bHQgaG9pc3QodXNlcmxhbmQsIFwiZGVmYXVsdFwiKTtcbi8vIFJlLWV4cG9ydCBtZXRob2RzLlxuZXhwb3J0IGNvbnN0IGdldFN0YXRpY1Byb3BzID0gaG9pc3QodXNlcmxhbmQsIFwiZ2V0U3RhdGljUHJvcHNcIik7XG5leHBvcnQgY29uc3QgZ2V0U3RhdGljUGF0aHMgPSBob2lzdCh1c2VybGFuZCwgXCJnZXRTdGF0aWNQYXRoc1wiKTtcbmV4cG9ydCBjb25zdCBnZXRTZXJ2ZXJTaWRlUHJvcHMgPSBob2lzdCh1c2VybGFuZCwgXCJnZXRTZXJ2ZXJTaWRlUHJvcHNcIik7XG5leHBvcnQgY29uc3QgY29uZmlnID0gaG9pc3QodXNlcmxhbmQsIFwiY29uZmlnXCIpO1xuZXhwb3J0IGNvbnN0IHJlcG9ydFdlYlZpdGFscyA9IGhvaXN0KHVzZXJsYW5kLCBcInJlcG9ydFdlYlZpdGFsc1wiKTtcbi8vIFJlLWV4cG9ydCBsZWdhY3kgbWV0aG9kcy5cbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTdGF0aWNQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCBcInVuc3RhYmxlX2dldFN0YXRpY1Byb3BzXCIpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1BhdGhzID0gaG9pc3QodXNlcmxhbmQsIFwidW5zdGFibGVfZ2V0U3RhdGljUGF0aHNcIik7XG5leHBvcnQgY29uc3QgdW5zdGFibGVfZ2V0U3RhdGljUGFyYW1zID0gaG9pc3QodXNlcmxhbmQsIFwidW5zdGFibGVfZ2V0U3RhdGljUGFyYW1zXCIpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFNlcnZlclByb3BzID0gaG9pc3QodXNlcmxhbmQsIFwidW5zdGFibGVfZ2V0U2VydmVyUHJvcHNcIik7XG5leHBvcnQgY29uc3QgdW5zdGFibGVfZ2V0U2VydmVyU2lkZVByb3BzID0gaG9pc3QodXNlcmxhbmQsIFwidW5zdGFibGVfZ2V0U2VydmVyU2lkZVByb3BzXCIpO1xuLy8gQ3JlYXRlIGFuZCBleHBvcnQgdGhlIHJvdXRlIG1vZHVsZSB0aGF0IHdpbGwgYmUgY29uc3VtZWQuXG5leHBvcnQgY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgUGFnZXNSb3V0ZU1vZHVsZSh7XG4gICAgZGVmaW5pdGlvbjoge1xuICAgICAgICBraW5kOiBSb3V0ZUtpbmQuUEFHRVMsXG4gICAgICAgIHBhZ2U6IFwiL2luZGV4XCIsXG4gICAgICAgIHBhdGhuYW1lOiBcIi9cIixcbiAgICAgICAgLy8gVGhlIGZvbGxvd2luZyBhcmVuJ3QgdXNlZCBpbiBwcm9kdWN0aW9uLlxuICAgICAgICBidW5kbGVQYXRoOiBcIlwiLFxuICAgICAgICBmaWxlbmFtZTogXCJcIlxuICAgIH0sXG4gICAgY29tcG9uZW50czoge1xuICAgICAgICBBcHAsXG4gICAgICAgIERvY3VtZW50XG4gICAgfSxcbiAgICB1c2VybGFuZFxufSk7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhZ2VzLmpzLm1hcCJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "./components/Carousel.js":
/*!********************************!*\
  !*** ./components/Carousel.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ProductCarousel)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Carousel_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Carousel,Container!=!react-bootstrap */ \"__barrel_optimize__?names=Carousel,Container!=!./node_modules/react-bootstrap/esm/index.js\");\n/* harmony import */ var _styles_Carousel_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/Carousel.module.css */ \"./styles/Carousel.module.css\");\n/* harmony import */ var _styles_Carousel_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_Carousel_module_css__WEBPACK_IMPORTED_MODULE_1__);\n\n\n\nfunction ProductCarousel({ products }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Carousel_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {\n        className: (_styles_Carousel_module_css__WEBPACK_IMPORTED_MODULE_1___default().carouselContainer),\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Carousel_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Carousel, {\n            className: (_styles_Carousel_module_css__WEBPACK_IMPORTED_MODULE_1___default().carousel),\n            children: products.slice(0, 5).map((product)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Carousel_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Carousel.Item, {\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n                            className: `d-block w-100 ${(_styles_Carousel_module_css__WEBPACK_IMPORTED_MODULE_1___default().carouselImage)}`,\n                            src: product.image,\n                            alt: product.title\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Carousel.js\",\n                            lineNumber: 10,\n                            columnNumber: 25\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Carousel_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Carousel.Caption, {\n                            className: (_styles_Carousel_module_css__WEBPACK_IMPORTED_MODULE_1___default().carouselCaption),\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                                    className: (_styles_Carousel_module_css__WEBPACK_IMPORTED_MODULE_1___default().productTitle),\n                                    children: product.title\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Carousel.js\",\n                                    lineNumber: 16,\n                                    columnNumber: 29\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                    className: (_styles_Carousel_module_css__WEBPACK_IMPORTED_MODULE_1___default().productPrice),\n                                    children: [\n                                        \"$\",\n                                        product.price\n                                    ]\n                                }, void 0, true, {\n                                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Carousel.js\",\n                                    lineNumber: 17,\n                                    columnNumber: 29\n                                }, this)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Carousel.js\",\n                            lineNumber: 15,\n                            columnNumber: 25\n                        }, this)\n                    ]\n                }, product.id, true, {\n                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Carousel.js\",\n                    lineNumber: 9,\n                    columnNumber: 21\n                }, this))\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Carousel.js\",\n            lineNumber: 7,\n            columnNumber: 13\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Carousel.js\",\n        lineNumber: 6,\n        columnNumber: 9\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0Nhcm91c2VsLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBc0Q7QUFDSDtBQUVwQyxTQUFTRyxnQkFBZ0IsRUFBRUMsUUFBUSxFQUFFO0lBQ2hELHFCQUNJLDhEQUFDSCxnR0FBU0E7UUFBQ0ksV0FBV0gsc0ZBQXdCO2tCQUMxQyw0RUFBQ0YsK0ZBQVFBO1lBQUNLLFdBQVdILDZFQUFlO3NCQUMvQkUsU0FBU0ksS0FBSyxDQUFDLEdBQUcsR0FBR0MsR0FBRyxDQUFDQyxDQUFBQSx3QkFDdEIsOERBQUNWLCtGQUFRQSxDQUFDVyxJQUFJOztzQ0FDViw4REFBQ0M7NEJBQ0dQLFdBQVcsQ0FBQyxjQUFjLEVBQUVILGtGQUFvQixDQUFDLENBQUM7NEJBQ2xEWSxLQUFLSixRQUFRSyxLQUFLOzRCQUNsQkMsS0FBS04sUUFBUU8sS0FBSzs7Ozs7O3NDQUV0Qiw4REFBQ2pCLCtGQUFRQSxDQUFDa0IsT0FBTzs0QkFBQ2IsV0FBV0gsb0ZBQXNCOzs4Q0FDL0MsOERBQUNrQjtvQ0FBR2YsV0FBV0gsaUZBQW1COzhDQUFHUSxRQUFRTyxLQUFLOzs7Ozs7OENBQ2xELDhEQUFDSztvQ0FBRWpCLFdBQVdILGlGQUFtQjs7d0NBQUU7d0NBQUVRLFFBQVFjLEtBQUs7Ozs7Ozs7Ozs7Ozs7O21CQVJ0Q2QsUUFBUWUsRUFBRTs7Ozs7Ozs7Ozs7Ozs7O0FBZWxEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2ViNDIyX2Fzc2lnbm1lbnRfMy8uL2NvbXBvbmVudHMvQ2Fyb3VzZWwuanM/MjdiOSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDYXJvdXNlbCwgQ29udGFpbmVyIH0gZnJvbSAncmVhY3QtYm9vdHN0cmFwJztcclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi9zdHlsZXMvQ2Fyb3VzZWwubW9kdWxlLmNzcyc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm9kdWN0Q2Fyb3VzZWwoeyBwcm9kdWN0cyB9KSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxDb250YWluZXIgY2xhc3NOYW1lPXtzdHlsZXMuY2Fyb3VzZWxDb250YWluZXJ9PlxyXG4gICAgICAgICAgICA8Q2Fyb3VzZWwgY2xhc3NOYW1lPXtzdHlsZXMuY2Fyb3VzZWx9PlxyXG4gICAgICAgICAgICAgICAge3Byb2R1Y3RzLnNsaWNlKDAsIDUpLm1hcChwcm9kdWN0ID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8Q2Fyb3VzZWwuSXRlbSBrZXk9e3Byb2R1Y3QuaWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BkLWJsb2NrIHctMTAwICR7c3R5bGVzLmNhcm91c2VsSW1hZ2V9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17cHJvZHVjdC5pbWFnZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17cHJvZHVjdC50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcm91c2VsLkNhcHRpb24gY2xhc3NOYW1lPXtzdHlsZXMuY2Fyb3VzZWxDYXB0aW9ufT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9e3N0eWxlcy5wcm9kdWN0VGl0bGV9Pntwcm9kdWN0LnRpdGxlfTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e3N0eWxlcy5wcm9kdWN0UHJpY2V9PiR7cHJvZHVjdC5wcmljZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQ2Fyb3VzZWwuQ2FwdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L0Nhcm91c2VsLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9DYXJvdXNlbD5cclxuICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICk7XHJcbn0iXSwibmFtZXMiOlsiQ2Fyb3VzZWwiLCJDb250YWluZXIiLCJzdHlsZXMiLCJQcm9kdWN0Q2Fyb3VzZWwiLCJwcm9kdWN0cyIsImNsYXNzTmFtZSIsImNhcm91c2VsQ29udGFpbmVyIiwiY2Fyb3VzZWwiLCJzbGljZSIsIm1hcCIsInByb2R1Y3QiLCJJdGVtIiwiaW1nIiwiY2Fyb3VzZWxJbWFnZSIsInNyYyIsImltYWdlIiwiYWx0IiwidGl0bGUiLCJDYXB0aW9uIiwiY2Fyb3VzZWxDYXB0aW9uIiwiaDMiLCJwcm9kdWN0VGl0bGUiLCJwIiwicHJvZHVjdFByaWNlIiwicHJpY2UiLCJpZCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/Carousel.js\n");

/***/ }),

/***/ "./components/Intro.js":
/*!*****************************!*\
  !*** ./components/Intro.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Intro)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Container!=!react-bootstrap */ \"__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js\");\n/* harmony import */ var _styles_Intro_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/Intro.module.css */ \"./styles/Intro.module.css\");\n/* harmony import */ var _styles_Intro_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_Intro_module_css__WEBPACK_IMPORTED_MODULE_1__);\n\n\n\nfunction Intro() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {\n        className: (_styles_Intro_module_css__WEBPACK_IMPORTED_MODULE_1___default().introContainer),\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                className: (_styles_Intro_module_css__WEBPACK_IMPORTED_MODULE_1___default().introText),\n                children: \"Welcome to FakeStore!\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Intro.js\",\n                lineNumber: 7,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: \"Your one-stop-shop for all the best fake products. Just don't ask where we got them.\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Intro.js\",\n                lineNumber: 8,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Intro.js\",\n        lineNumber: 6,\n        columnNumber: 9\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0ludHJvLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBNEM7QUFDSTtBQUVqQyxTQUFTRTtJQUNwQixxQkFDSSw4REFBQ0YsdUZBQVNBO1FBQUNHLFdBQVdGLGdGQUFxQjs7MEJBQ3ZDLDhEQUFDSTtnQkFBR0YsV0FBV0YsMkVBQWdCOzBCQUFFOzs7Ozs7MEJBQ2pDLDhEQUFDTTswQkFBRTs7Ozs7Ozs7Ozs7O0FBR2YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly93ZWI0MjJfYXNzaWdubWVudF8zLy4vY29tcG9uZW50cy9JbnRyby5qcz8zZWVmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbnRhaW5lciB9IGZyb20gJ3JlYWN0LWJvb3RzdHJhcCc7XHJcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi4vc3R5bGVzL0ludHJvLm1vZHVsZS5jc3MnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSW50cm8oKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxDb250YWluZXIgY2xhc3NOYW1lPXtzdHlsZXMuaW50cm9Db250YWluZXJ9PlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPXtzdHlsZXMuaW50cm9UZXh0fT5XZWxjb21lIHRvIEZha2VTdG9yZSE8L2gxPlxyXG4gICAgICAgICAgICA8cD5Zb3VyIG9uZS1zdG9wLXNob3AgZm9yIGFsbCB0aGUgYmVzdCBmYWtlIHByb2R1Y3RzLiBKdXN0IGRvbid0IGFzayB3aGVyZSB3ZSBnb3QgdGhlbS48L3A+XHJcbiAgICAgICAgPC9Db250YWluZXI+XHJcbiAgICApO1xyXG59Il0sIm5hbWVzIjpbIkNvbnRhaW5lciIsInN0eWxlcyIsIkludHJvIiwiY2xhc3NOYW1lIiwiaW50cm9Db250YWluZXIiLCJoMSIsImludHJvVGV4dCIsInAiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/Intro.js\n");

/***/ }),

/***/ "./components/Intro2.js":
/*!******************************!*\
  !*** ./components/Intro2.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Intro2)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Container!=!react-bootstrap */ \"__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js\");\n/* harmony import */ var _styles_Intro_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/Intro.module.css */ \"./styles/Intro.module.css\");\n/* harmony import */ var _styles_Intro_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_Intro_module_css__WEBPACK_IMPORTED_MODULE_1__);\n\n\n\nfunction Intro2() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {\n        className: (_styles_Intro_module_css__WEBPACK_IMPORTED_MODULE_1___default().introContainer),\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                className: (_styles_Intro_module_css__WEBPACK_IMPORTED_MODULE_1___default().introText),\n                children: \"Check out our current sales!\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Intro2.js\",\n                lineNumber: 7,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: \"The hottest seasonal merch.\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Intro2.js\",\n                lineNumber: 8,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Intro2.js\",\n        lineNumber: 6,\n        columnNumber: 9\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0ludHJvMi5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQTRDO0FBQ0k7QUFFakMsU0FBU0U7SUFDcEIscUJBQ0ksOERBQUNGLHVGQUFTQTtRQUFDRyxXQUFXRixnRkFBcUI7OzBCQUN2Qyw4REFBQ0k7Z0JBQUdGLFdBQVdGLDJFQUFnQjswQkFBRTs7Ozs7OzBCQUNqQyw4REFBQ007MEJBQUU7Ozs7Ozs7Ozs7OztBQUdmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2ViNDIyX2Fzc2lnbm1lbnRfMy8uL2NvbXBvbmVudHMvSW50cm8yLmpzP2I1ZDAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29udGFpbmVyIH0gZnJvbSAncmVhY3QtYm9vdHN0cmFwJztcclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi9zdHlsZXMvSW50cm8ubW9kdWxlLmNzcyc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBJbnRybzIoKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxDb250YWluZXIgY2xhc3NOYW1lPXtzdHlsZXMuaW50cm9Db250YWluZXJ9PlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPXtzdHlsZXMuaW50cm9UZXh0fT5DaGVjayBvdXQgb3VyIGN1cnJlbnQgc2FsZXMhPC9oMT5cclxuICAgICAgICAgICAgPHA+VGhlIGhvdHRlc3Qgc2Vhc29uYWwgbWVyY2guPC9wPlxyXG4gICAgICAgIDwvQ29udGFpbmVyPlxyXG4gICAgKTtcclxufSJdLCJuYW1lcyI6WyJDb250YWluZXIiLCJzdHlsZXMiLCJJbnRybzIiLCJjbGFzc05hbWUiLCJpbnRyb0NvbnRhaW5lciIsImgxIiwiaW50cm9UZXh0IiwicCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/Intro2.js\n");

/***/ }),

/***/ "./components/Layout.js":
/*!******************************!*\
  !*** ./components/Layout.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Navbar */ \"./components/Navbar.js\");\n\n\nfunction Layout({ children }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Navbar__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Layout.js\",\n                lineNumber: 6,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n                children: children\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Layout.js\",\n                lineNumber: 7,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0xheW91dC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFvQztBQUVyQixTQUFTQyxPQUFPLEVBQUVDLFFBQVEsRUFBRTtJQUN2QyxxQkFDSTs7MEJBQ0ksOERBQUNGLCtDQUFZQTs7Ozs7MEJBQ2IsOERBQUNHOzBCQUFNRDs7Ozs7Ozs7QUFHbkIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly93ZWI0MjJfYXNzaWdubWVudF8zLy4vY29tcG9uZW50cy9MYXlvdXQuanM/NTE1YyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQ3VzdG9tTmF2YmFyIGZyb20gJy4vTmF2YmFyJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dCh7IGNoaWxkcmVuIH0pIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPEN1c3RvbU5hdmJhciAvPlxyXG4gICAgICAgICAgICA8bWFpbj57Y2hpbGRyZW59PC9tYWluPlxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufVxyXG4iXSwibmFtZXMiOlsiQ3VzdG9tTmF2YmFyIiwiTGF5b3V0IiwiY2hpbGRyZW4iLCJtYWluIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/Layout.js\n");

/***/ }),

/***/ "./components/Navbar.js":
/*!******************************!*\
  !*** ./components/Navbar.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ CustomNavbar)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Container,Form,FormControl,Nav,Navbar!=!react-bootstrap */ \"__barrel_optimize__?names=Button,Container,Form,FormControl,Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js\");\n\n\n\n\nfunction CustomNavbar() {\n    const [searchTerm, setSearchTerm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const handleSearch = (e)=>{\n        e.preventDefault();\n        router.push(`/products?search=${encodeURIComponent(searchTerm)}`);\n    };\n    const handleNavigation = (e, path)=>{\n        e.preventDefault();\n        router.push(path);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar, {\n        bg: \"light\",\n        expand: \"lg\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Container, {\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar.Brand, {\n                    href: \"/\",\n                    onClick: (e)=>handleNavigation(e, \"/\"),\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n                            src: \"/img/header_logo.png\",\n                            width: \"30\",\n                            height: \"30\",\n                            className: \"d-inline-block align-top\",\n                            alt: \"Logo\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Navbar.js\",\n                            lineNumber: 23,\n                            columnNumber: 21\n                        }, this),\n                        \" \",\n                        \"Chris Simon - Web Assignment 3\"\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Navbar.js\",\n                    lineNumber: 22,\n                    columnNumber: 17\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar.Toggle, {\n                    \"aria-controls\": \"basic-navbar-nav\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Navbar.js\",\n                    lineNumber: 33,\n                    columnNumber: 17\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar.Collapse, {\n                    id: \"basic-navbar-nav\",\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav, {\n                            className: \"me-auto\",\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav.Link, {\n                                    href: \"/\",\n                                    onClick: (e)=>handleNavigation(e, \"/\"),\n                                    children: \"Home\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Navbar.js\",\n                                    lineNumber: 36,\n                                    columnNumber: 25\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav.Link, {\n                                    href: \"/about\",\n                                    onClick: (e)=>handleNavigation(e, \"/about\"),\n                                    children: \"About\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Navbar.js\",\n                                    lineNumber: 37,\n                                    columnNumber: 25\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav.Link, {\n                                    href: \"/products\",\n                                    onClick: (e)=>handleNavigation(e, \"/products\"),\n                                    children: \"Products\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Navbar.js\",\n                                    lineNumber: 38,\n                                    columnNumber: 25\n                                }, this)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Navbar.js\",\n                            lineNumber: 35,\n                            columnNumber: 21\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form, {\n                            className: \"d-flex\",\n                            onSubmit: handleSearch,\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.FormControl, {\n                                    type: \"search\",\n                                    placeholder: \"Search Products\",\n                                    className: \"me-2\",\n                                    \"aria-label\": \"Search\",\n                                    value: searchTerm,\n                                    onChange: (e)=>setSearchTerm(e.target.value)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Navbar.js\",\n                                    lineNumber: 41,\n                                    columnNumber: 25\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Button, {\n                                    variant: \"outline-success\",\n                                    type: \"submit\",\n                                    children: \"Search\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Navbar.js\",\n                                    lineNumber: 49,\n                                    columnNumber: 25\n                                }, this)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Navbar.js\",\n                            lineNumber: 40,\n                            columnNumber: 21\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Navbar.js\",\n                    lineNumber: 34,\n                    columnNumber: 17\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Navbar.js\",\n            lineNumber: 21,\n            columnNumber: 13\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\Navbar.js\",\n        lineNumber: 20,\n        columnNumber: 9\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL05hdmJhci5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBaUM7QUFDTztBQUM0QztBQUVyRSxTQUFTUTtJQUNwQixNQUFNLENBQUNDLFlBQVlDLGNBQWMsR0FBR1YsK0NBQVFBLENBQUM7SUFDN0MsTUFBTVcsU0FBU1Ysc0RBQVNBO0lBRXhCLE1BQU1XLGVBQWUsQ0FBQ0M7UUFDbEJBLEVBQUVDLGNBQWM7UUFDaEJILE9BQU9JLElBQUksQ0FBQyxDQUFDLGlCQUFpQixFQUFFQyxtQkFBbUJQLFlBQVksQ0FBQztJQUNwRTtJQUVBLE1BQU1RLG1CQUFtQixDQUFDSixHQUFHSztRQUN6QkwsRUFBRUMsY0FBYztRQUNoQkgsT0FBT0ksSUFBSSxDQUFDRztJQUNoQjtJQUVBLHFCQUNJLDhEQUFDaEIsdUhBQU1BO1FBQUNpQixJQUFHO1FBQVFDLFFBQU87a0JBQ3RCLDRFQUFDaEIsMEhBQVNBOzs4QkFDTiw4REFBQ0YsdUhBQU1BLENBQUNtQixLQUFLO29CQUFDQyxNQUFLO29CQUFJQyxTQUFTLENBQUNWLElBQU1JLGlCQUFpQkosR0FBRzs7c0NBQ3ZELDhEQUFDVzs0QkFDR0MsS0FBSTs0QkFDSkMsT0FBTTs0QkFDTkMsUUFBTzs0QkFDUEMsV0FBVTs0QkFDVkMsS0FBSTs7Ozs7O3dCQUVQO3dCQUFJOzs7Ozs7OzhCQUdULDhEQUFDM0IsdUhBQU1BLENBQUM0QixNQUFNO29CQUFDQyxpQkFBYzs7Ozs7OzhCQUM3Qiw4REFBQzdCLHVIQUFNQSxDQUFDOEIsUUFBUTtvQkFBQ0MsSUFBRzs7c0NBQ2hCLDhEQUFDOUIsb0hBQUdBOzRCQUFDeUIsV0FBVTs7OENBQ1gsOERBQUN6QixvSEFBR0EsQ0FBQytCLElBQUk7b0NBQUNaLE1BQUs7b0NBQUlDLFNBQVMsQ0FBQ1YsSUFBTUksaUJBQWlCSixHQUFHOzhDQUFNOzs7Ozs7OENBQzdELDhEQUFDVixvSEFBR0EsQ0FBQytCLElBQUk7b0NBQUNaLE1BQUs7b0NBQVNDLFNBQVMsQ0FBQ1YsSUFBTUksaUJBQWlCSixHQUFHOzhDQUFXOzs7Ozs7OENBQ3ZFLDhEQUFDVixvSEFBR0EsQ0FBQytCLElBQUk7b0NBQUNaLE1BQUs7b0NBQVlDLFNBQVMsQ0FBQ1YsSUFBTUksaUJBQWlCSixHQUFHOzhDQUFjOzs7Ozs7Ozs7Ozs7c0NBRWpGLDhEQUFDUixxSEFBSUE7NEJBQUN1QixXQUFVOzRCQUFTTyxVQUFVdkI7OzhDQUMvQiw4REFBQ04sNEhBQVdBO29DQUNSOEIsTUFBSztvQ0FDTEMsYUFBWTtvQ0FDWlQsV0FBVTtvQ0FDVlUsY0FBVztvQ0FDWEMsT0FBTzlCO29DQUNQK0IsVUFBVSxDQUFDM0IsSUFBTUgsY0FBY0csRUFBRTRCLE1BQU0sQ0FBQ0YsS0FBSzs7Ozs7OzhDQUVqRCw4REFBQ2hDLHVIQUFNQTtvQ0FBQ21DLFNBQVE7b0NBQWtCTixNQUFLOzhDQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQU14RSIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYjQyMl9hc3NpZ25tZW50XzMvLi9jb21wb25lbnRzL05hdmJhci5qcz9mYmNhIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XHJcbmltcG9ydCB7IE5hdmJhciwgTmF2LCBDb250YWluZXIsIEZvcm0sIEZvcm1Db250cm9sLCBCdXR0b24gfSBmcm9tICdyZWFjdC1ib290c3RyYXAnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ3VzdG9tTmF2YmFyKCkge1xyXG4gICAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlU2VhcmNoID0gKGUpID0+IHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgcm91dGVyLnB1c2goYC9wcm9kdWN0cz9zZWFyY2g9JHtlbmNvZGVVUklDb21wb25lbnQoc2VhcmNoVGVybSl9YCk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZU5hdmlnYXRpb24gPSAoZSwgcGF0aCkgPT4ge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICByb3V0ZXIucHVzaChwYXRoKTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8TmF2YmFyIGJnPVwibGlnaHRcIiBleHBhbmQ9XCJsZ1wiPlxyXG4gICAgICAgICAgICA8Q29udGFpbmVyPlxyXG4gICAgICAgICAgICAgICAgPE5hdmJhci5CcmFuZCBocmVmPVwiL1wiIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVOYXZpZ2F0aW9uKGUsICcvJyl9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3JjPVwiL2ltZy9oZWFkZXJfbG9nby5wbmdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aD1cIjMwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PVwiMzBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJkLWlubGluZS1ibG9jayBhbGlnbi10b3BcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJMb2dvXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHsnICd9XHJcbiAgICAgICAgICAgICAgICAgICAgQ2hyaXMgU2ltb24gLSBXZWIgQXNzaWdubWVudCAzXHJcbiAgICAgICAgICAgICAgICA8L05hdmJhci5CcmFuZD5cclxuICAgICAgICAgICAgICAgIDxOYXZiYXIuVG9nZ2xlIGFyaWEtY29udHJvbHM9XCJiYXNpYy1uYXZiYXItbmF2XCIgLz5cclxuICAgICAgICAgICAgICAgIDxOYXZiYXIuQ29sbGFwc2UgaWQ9XCJiYXNpYy1uYXZiYXItbmF2XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPE5hdiBjbGFzc05hbWU9XCJtZS1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxOYXYuTGluayBocmVmPVwiL1wiIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVOYXZpZ2F0aW9uKGUsICcvJyl9PkhvbWU8L05hdi5MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TmF2LkxpbmsgaHJlZj1cIi9hYm91dFwiIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVOYXZpZ2F0aW9uKGUsICcvYWJvdXQnKX0+QWJvdXQ8L05hdi5MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TmF2LkxpbmsgaHJlZj1cIi9wcm9kdWN0c1wiIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVOYXZpZ2F0aW9uKGUsICcvcHJvZHVjdHMnKX0+UHJvZHVjdHM8L05hdi5MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvTmF2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxGb3JtIGNsYXNzTmFtZT1cImQtZmxleFwiIG9uU3VibWl0PXtoYW5kbGVTZWFyY2h9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUNvbnRyb2xcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzZWFyY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggUHJvZHVjdHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWUtMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiU2VhcmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hUZXJtfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hUZXJtKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZS1zdWNjZXNzXCIgdHlwZT1cInN1Ym1pdFwiPlNlYXJjaDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvRm9ybT5cclxuICAgICAgICAgICAgICAgIDwvTmF2YmFyLkNvbGxhcHNlPlxyXG4gICAgICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgICA8L05hdmJhcj5cclxuICAgICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlUm91dGVyIiwiTmF2YmFyIiwiTmF2IiwiQ29udGFpbmVyIiwiRm9ybSIsIkZvcm1Db250cm9sIiwiQnV0dG9uIiwiQ3VzdG9tTmF2YmFyIiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJyb3V0ZXIiLCJoYW5kbGVTZWFyY2giLCJlIiwicHJldmVudERlZmF1bHQiLCJwdXNoIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwiaGFuZGxlTmF2aWdhdGlvbiIsInBhdGgiLCJiZyIsImV4cGFuZCIsIkJyYW5kIiwiaHJlZiIsIm9uQ2xpY2siLCJpbWciLCJzcmMiLCJ3aWR0aCIsImhlaWdodCIsImNsYXNzTmFtZSIsImFsdCIsIlRvZ2dsZSIsImFyaWEtY29udHJvbHMiLCJDb2xsYXBzZSIsImlkIiwiTGluayIsIm9uU3VibWl0IiwidHlwZSIsInBsYWNlaG9sZGVyIiwiYXJpYS1sYWJlbCIsInZhbHVlIiwib25DaGFuZ2UiLCJ0YXJnZXQiLCJ2YXJpYW50Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/Navbar.js\n");

/***/ }),

/***/ "./components/ProductModal.js":
/*!************************************!*\
  !*** ./components/ProductModal.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ProductModal)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Button_Image_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Image,Modal!=!react-bootstrap */ \"__barrel_optimize__?names=Button,Image,Modal!=!./node_modules/react-bootstrap/esm/index.js\");\n\n\nfunction ProductModal({ show, handleClose, product }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Image_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_1__.Modal, {\n        show: show,\n        onHide: handleClose,\n        centered: true,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Image_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_1__.Modal.Header, {\n                closeButton: true,\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Image_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_1__.Modal.Title, {\n                    children: product?.title\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\ProductModal.js\",\n                    lineNumber: 7,\n                    columnNumber: 17\n                }, this)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\ProductModal.js\",\n                lineNumber: 6,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Image_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_1__.Modal.Body, {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Image_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_1__.Image, {\n                        src: product?.image,\n                        fluid: true\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\ProductModal.js\",\n                        lineNumber: 10,\n                        columnNumber: 17\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                        children: product?.description\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\ProductModal.js\",\n                        lineNumber: 11,\n                        columnNumber: 17\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                        children: [\n                            \"$\",\n                            product?.price\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\ProductModal.js\",\n                        lineNumber: 12,\n                        columnNumber: 17\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                        children: [\n                            \"Category: \",\n                            product?.category\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\ProductModal.js\",\n                        lineNumber: 13,\n                        columnNumber: 17\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                        children: [\n                            \"Rating: \",\n                            product?.rating?.rate,\n                            \" (\",\n                            product?.rating?.count,\n                            \" Reviews)\"\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\ProductModal.js\",\n                        lineNumber: 14,\n                        columnNumber: 17\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\ProductModal.js\",\n                lineNumber: 9,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Image_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_1__.Modal.Footer, {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Image_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_1__.Button, {\n                    variant: \"secondary\",\n                    onClick: handleClose,\n                    children: \"Close\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\ProductModal.js\",\n                    lineNumber: 17,\n                    columnNumber: 17\n                }, this)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\ProductModal.js\",\n                lineNumber: 16,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\ProductModal.js\",\n        lineNumber: 5,\n        columnNumber: 9\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL1Byb2R1Y3RNb2RhbC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUF1RDtBQUV4QyxTQUFTRyxhQUFhLEVBQUVDLElBQUksRUFBRUMsV0FBVyxFQUFFQyxPQUFPLEVBQUU7SUFDL0QscUJBQ0ksOERBQUNOLDRGQUFLQTtRQUFDSSxNQUFNQTtRQUFNRyxRQUFRRjtRQUFhRyxRQUFROzswQkFDNUMsOERBQUNSLDRGQUFLQSxDQUFDUyxNQUFNO2dCQUFDQyxXQUFXOzBCQUNyQiw0RUFBQ1YsNEZBQUtBLENBQUNXLEtBQUs7OEJBQUVMLFNBQVNNOzs7Ozs7Ozs7OzswQkFFM0IsOERBQUNaLDRGQUFLQSxDQUFDYSxJQUFJOztrQ0FDUCw4REFBQ1gsNEZBQUtBO3dCQUFDWSxLQUFLUixTQUFTUzt3QkFBT0MsS0FBSzs7Ozs7O2tDQUNqQyw4REFBQ0M7a0NBQUdYLFNBQVNZOzs7Ozs7a0NBQ2IsOERBQUNDOzs0QkFBRzs0QkFBRWIsU0FBU2M7Ozs7Ozs7a0NBQ2YsOERBQUNIOzs0QkFBRTs0QkFBV1gsU0FBU2U7Ozs7Ozs7a0NBQ3ZCLDhEQUFDSjs7NEJBQUU7NEJBQVNYLFNBQVNnQixRQUFRQzs0QkFBSzs0QkFBR2pCLFNBQVNnQixRQUFRRTs0QkFBTTs7Ozs7Ozs7Ozs7OzswQkFFaEUsOERBQUN4Qiw0RkFBS0EsQ0FBQ3lCLE1BQU07MEJBQ1QsNEVBQUN4Qiw2RkFBTUE7b0JBQUN5QixTQUFRO29CQUFZQyxTQUFTdEI7OEJBQWE7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBTWxFIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2ViNDIyX2Fzc2lnbm1lbnRfMy8uL2NvbXBvbmVudHMvUHJvZHVjdE1vZGFsLmpzPzIxZmEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9kYWwsIEJ1dHRvbiwgSW1hZ2UgfSBmcm9tICdyZWFjdC1ib290c3RyYXAnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvZHVjdE1vZGFsKHsgc2hvdywgaGFuZGxlQ2xvc2UsIHByb2R1Y3QgfSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8TW9kYWwgc2hvdz17c2hvd30gb25IaWRlPXtoYW5kbGVDbG9zZX0gY2VudGVyZWQ+XHJcbiAgICAgICAgICAgIDxNb2RhbC5IZWFkZXIgY2xvc2VCdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8TW9kYWwuVGl0bGU+e3Byb2R1Y3Q/LnRpdGxlfTwvTW9kYWwuVGl0bGU+XHJcbiAgICAgICAgICAgIDwvTW9kYWwuSGVhZGVyPlxyXG4gICAgICAgICAgICA8TW9kYWwuQm9keT5cclxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9e3Byb2R1Y3Q/LmltYWdlfSBmbHVpZCAvPlxyXG4gICAgICAgICAgICAgICAgPHA+e3Byb2R1Y3Q/LmRlc2NyaXB0aW9ufTwvcD5cclxuICAgICAgICAgICAgICAgIDxoMz4ke3Byb2R1Y3Q/LnByaWNlfTwvaDM+XHJcbiAgICAgICAgICAgICAgICA8cD5DYXRlZ29yeToge3Byb2R1Y3Q/LmNhdGVnb3J5fTwvcD5cclxuICAgICAgICAgICAgICAgIDxwPlJhdGluZzoge3Byb2R1Y3Q/LnJhdGluZz8ucmF0ZX0gKHtwcm9kdWN0Py5yYXRpbmc/LmNvdW50fSBSZXZpZXdzKTwvcD5cclxuICAgICAgICAgICAgPC9Nb2RhbC5Cb2R5PlxyXG4gICAgICAgICAgICA8TW9kYWwuRm9vdGVyPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17aGFuZGxlQ2xvc2V9PlxyXG4gICAgICAgICAgICAgICAgICAgIENsb3NlXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9Nb2RhbC5Gb290ZXI+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICk7XHJcbn0iXSwibmFtZXMiOlsiTW9kYWwiLCJCdXR0b24iLCJJbWFnZSIsIlByb2R1Y3RNb2RhbCIsInNob3ciLCJoYW5kbGVDbG9zZSIsInByb2R1Y3QiLCJvbkhpZGUiLCJjZW50ZXJlZCIsIkhlYWRlciIsImNsb3NlQnV0dG9uIiwiVGl0bGUiLCJ0aXRsZSIsIkJvZHkiLCJzcmMiLCJpbWFnZSIsImZsdWlkIiwicCIsImRlc2NyaXB0aW9uIiwiaDMiLCJwcmljZSIsImNhdGVnb3J5IiwicmF0aW5nIiwicmF0ZSIsImNvdW50IiwiRm9vdGVyIiwidmFyaWFudCIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/ProductModal.js\n");

/***/ }),

/***/ "./components/RandomProducts.js":
/*!**************************************!*\
  !*** ./components/RandomProducts.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ RandomProducts)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _barrel_optimize_names_Card_Col_Container_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=Card,Col,Container,Row!=!react-bootstrap */ \"__barrel_optimize__?names=Card,Col,Container,Row!=!./node_modules/react-bootstrap/esm/index.js\");\n/* harmony import */ var _styles_RandomProducts_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/RandomProducts.module.css */ \"./styles/RandomProducts.module.css\");\n/* harmony import */ var _styles_RandomProducts_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_RandomProducts_module_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _ProductModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ProductModal */ \"./components/ProductModal.js\");\n\n\n\n\n\nfunction RandomProducts() {\n    const [products, setProducts] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);\n    const [selectedProduct, setSelectedProduct] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    const [showModal, setShowModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        fetch(\"https://fakestoreapi.com/products\").then((res)=>res.json()).then((data)=>{\n            const shuffled = data.sort(()=>0.5 - Math.random());\n            const selected = shuffled.slice(0, 6);\n            setProducts(selected);\n        });\n    }, []);\n    const handleShowModal = (product)=>{\n        setSelectedProduct(product);\n        setShowModal(true);\n    };\n    const handleCloseModal = ()=>{\n        setSelectedProduct(null);\n        setShowModal(false);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Card_Col_Container_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Container, {\n                className: (_styles_RandomProducts_module_css__WEBPACK_IMPORTED_MODULE_2___default().productsContainer),\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Card_Col_Container_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Row, {\n                    children: products.map((product)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Card_Col_Container_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Col, {\n                            xs: 12,\n                            sm: 6,\n                            md: 4,\n                            className: \"mb-4\",\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Card_Col_Container_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Card, {\n                                onClick: ()=>handleShowModal(product),\n                                className: (_styles_RandomProducts_module_css__WEBPACK_IMPORTED_MODULE_2___default().card),\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Card_Col_Container_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Card.Img, {\n                                        variant: \"top\",\n                                        src: product.image\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\RandomProducts.js\",\n                                        lineNumber: 38,\n                                        columnNumber: 33\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Card_Col_Container_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Card.Body, {\n                                        children: [\n                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Card_Col_Container_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Card.Title, {\n                                                children: product.title\n                                            }, void 0, false, {\n                                                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\RandomProducts.js\",\n                                                lineNumber: 40,\n                                                columnNumber: 37\n                                            }, this),\n                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Card_Col_Container_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Card.Text, {\n                                                children: [\n                                                    \"$\",\n                                                    product.price\n                                                ]\n                                            }, void 0, true, {\n                                                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\RandomProducts.js\",\n                                                lineNumber: 41,\n                                                columnNumber: 37\n                                            }, this)\n                                        ]\n                                    }, void 0, true, {\n                                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\RandomProducts.js\",\n                                        lineNumber: 39,\n                                        columnNumber: 33\n                                    }, this)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\RandomProducts.js\",\n                                lineNumber: 37,\n                                columnNumber: 29\n                            }, this)\n                        }, product.id, false, {\n                            fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\RandomProducts.js\",\n                            lineNumber: 36,\n                            columnNumber: 25\n                        }, this))\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\RandomProducts.js\",\n                    lineNumber: 34,\n                    columnNumber: 17\n                }, this)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\RandomProducts.js\",\n                lineNumber: 33,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_ProductModal__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n                show: showModal,\n                handleClose: handleCloseModal,\n                product: selectedProduct\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\components\\\\RandomProducts.js\",\n                lineNumber: 48,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL1JhbmRvbVByb2R1Y3RzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBNEM7QUFDZ0I7QUFDSDtBQUNmO0FBRTNCLFNBQVNRO0lBQ3BCLE1BQU0sQ0FBQ0MsVUFBVUMsWUFBWSxHQUFHViwrQ0FBUUEsQ0FBQyxFQUFFO0lBQzNDLE1BQU0sQ0FBQ1csaUJBQWlCQyxtQkFBbUIsR0FBR1osK0NBQVFBLENBQUM7SUFDdkQsTUFBTSxDQUFDYSxXQUFXQyxhQUFhLEdBQUdkLCtDQUFRQSxDQUFDO0lBRTNDQyxnREFBU0EsQ0FBQztRQUNOYyxNQUFNLHFDQUNEQyxJQUFJLENBQUNDLENBQUFBLE1BQU9BLElBQUlDLElBQUksSUFDcEJGLElBQUksQ0FBQ0csQ0FBQUE7WUFDRixNQUFNQyxXQUFXRCxLQUFLRSxJQUFJLENBQUMsSUFBTSxNQUFNQyxLQUFLQyxNQUFNO1lBQ2xELE1BQU1DLFdBQVdKLFNBQVNLLEtBQUssQ0FBQyxHQUFHO1lBQ25DZixZQUFZYztRQUNoQjtJQUNSLEdBQUcsRUFBRTtJQUVMLE1BQU1FLGtCQUFrQixDQUFDQztRQUNyQmYsbUJBQW1CZTtRQUNuQmIsYUFBYTtJQUNqQjtJQUVBLE1BQU1jLG1CQUFtQjtRQUNyQmhCLG1CQUFtQjtRQUNuQkUsYUFBYTtJQUNqQjtJQUVBLHFCQUNJOzswQkFDSSw4REFBQ1osb0dBQVNBO2dCQUFDMkIsV0FBV3ZCLDRGQUF3QjswQkFDMUMsNEVBQUNILDhGQUFHQTs4QkFDQ00sU0FBU3NCLEdBQUcsQ0FBQ0osQ0FBQUEsd0JBQ1YsOERBQUN2Qiw4RkFBR0E7NEJBQWtCNEIsSUFBSTs0QkFBSUMsSUFBSTs0QkFBR0MsSUFBSTs0QkFBR0wsV0FBVTtzQ0FDbEQsNEVBQUN4QiwrRkFBSUE7Z0NBQUM4QixTQUFTLElBQU1ULGdCQUFnQkM7Z0NBQVVFLFdBQVd2QiwrRUFBVzs7a0RBQ2pFLDhEQUFDRCwrRkFBSUEsQ0FBQ2dDLEdBQUc7d0NBQUNDLFNBQVE7d0NBQU1DLEtBQUtaLFFBQVFhLEtBQUs7Ozs7OztrREFDMUMsOERBQUNuQywrRkFBSUEsQ0FBQ29DLElBQUk7OzBEQUNOLDhEQUFDcEMsK0ZBQUlBLENBQUNxQyxLQUFLOzBEQUFFZixRQUFRZ0IsS0FBSzs7Ozs7OzBEQUMxQiw4REFBQ3RDLCtGQUFJQSxDQUFDdUMsSUFBSTs7b0RBQUM7b0RBQUVqQixRQUFRa0IsS0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsyQkFMNUJsQixRQUFRbUIsRUFBRTs7Ozs7Ozs7Ozs7Ozs7OzBCQVloQyw4REFBQ3ZDLHFEQUFZQTtnQkFDVHdDLE1BQU1sQztnQkFDTm1DLGFBQWFwQjtnQkFDYkQsU0FBU2hCOzs7Ozs7OztBQUl6QiIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYjQyMl9hc3NpZ25tZW50XzMvLi9jb21wb25lbnRzL1JhbmRvbVByb2R1Y3RzLmpzP2ZkZjAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQ29udGFpbmVyLCBSb3csIENvbCwgQ2FyZCB9IGZyb20gJ3JlYWN0LWJvb3RzdHJhcCc7XHJcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi4vc3R5bGVzL1JhbmRvbVByb2R1Y3RzLm1vZHVsZS5jc3MnO1xyXG5pbXBvcnQgUHJvZHVjdE1vZGFsIGZyb20gJy4vUHJvZHVjdE1vZGFsJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJhbmRvbVByb2R1Y3RzKCkge1xyXG4gICAgY29uc3QgW3Byb2R1Y3RzLCBzZXRQcm9kdWN0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbc2VsZWN0ZWRQcm9kdWN0LCBzZXRTZWxlY3RlZFByb2R1Y3RdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgZmV0Y2goJ2h0dHBzOi8vZmFrZXN0b3JlYXBpLmNvbS9wcm9kdWN0cycpXHJcbiAgICAgICAgICAgIC50aGVuKHJlcyA9PiByZXMuanNvbigpKVxyXG4gICAgICAgICAgICAudGhlbihkYXRhID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHNodWZmbGVkID0gZGF0YS5zb3J0KCgpID0+IDAuNSAtIE1hdGgucmFuZG9tKCkpO1xyXG4gICAgICAgICAgICAgICAgY29uc3Qgc2VsZWN0ZWQgPSBzaHVmZmxlZC5zbGljZSgwLCA2KTtcclxuICAgICAgICAgICAgICAgIHNldFByb2R1Y3RzKHNlbGVjdGVkKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlU2hvd01vZGFsID0gKHByb2R1Y3QpID0+IHtcclxuICAgICAgICBzZXRTZWxlY3RlZFByb2R1Y3QocHJvZHVjdCk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVDbG9zZU1vZGFsID0gKCkgPT4ge1xyXG4gICAgICAgIHNldFNlbGVjdGVkUHJvZHVjdChudWxsKTtcclxuICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxDb250YWluZXIgY2xhc3NOYW1lPXtzdHlsZXMucHJvZHVjdHNDb250YWluZXJ9PlxyXG4gICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICB7cHJvZHVjdHMubWFwKHByb2R1Y3QgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q29sIGtleT17cHJvZHVjdC5pZH0geHM9ezEyfSBzbT17Nn0gbWQ9ezR9IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNob3dNb2RhbChwcm9kdWN0KX0gY2xhc3NOYW1lPXtzdHlsZXMuY2FyZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhcmQuSW1nIHZhcmlhbnQ9XCJ0b3BcIiBzcmM9e3Byb2R1Y3QuaW1hZ2V9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhcmQuQm9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhcmQuVGl0bGU+e3Byb2R1Y3QudGl0bGV9PC9DYXJkLlRpdGxlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2FyZC5UZXh0PiR7cHJvZHVjdC5wcmljZX08L0NhcmQuVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmQuQm9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgPC9Db250YWluZXI+XHJcbiAgICAgICAgICAgIDxQcm9kdWN0TW9kYWxcclxuICAgICAgICAgICAgICAgIHNob3c9e3Nob3dNb2RhbH1cclxuICAgICAgICAgICAgICAgIGhhbmRsZUNsb3NlPXtoYW5kbGVDbG9zZU1vZGFsfVxyXG4gICAgICAgICAgICAgICAgcHJvZHVjdD17c2VsZWN0ZWRQcm9kdWN0fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufSJdLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkNvbnRhaW5lciIsIlJvdyIsIkNvbCIsIkNhcmQiLCJzdHlsZXMiLCJQcm9kdWN0TW9kYWwiLCJSYW5kb21Qcm9kdWN0cyIsInByb2R1Y3RzIiwic2V0UHJvZHVjdHMiLCJzZWxlY3RlZFByb2R1Y3QiLCJzZXRTZWxlY3RlZFByb2R1Y3QiLCJzaG93TW9kYWwiLCJzZXRTaG93TW9kYWwiLCJmZXRjaCIsInRoZW4iLCJyZXMiLCJqc29uIiwiZGF0YSIsInNodWZmbGVkIiwic29ydCIsIk1hdGgiLCJyYW5kb20iLCJzZWxlY3RlZCIsInNsaWNlIiwiaGFuZGxlU2hvd01vZGFsIiwicHJvZHVjdCIsImhhbmRsZUNsb3NlTW9kYWwiLCJjbGFzc05hbWUiLCJwcm9kdWN0c0NvbnRhaW5lciIsIm1hcCIsInhzIiwic20iLCJtZCIsIm9uQ2xpY2siLCJjYXJkIiwiSW1nIiwidmFyaWFudCIsInNyYyIsImltYWdlIiwiQm9keSIsIlRpdGxlIiwidGl0bGUiLCJUZXh0IiwicHJpY2UiLCJpZCIsInNob3ciLCJoYW5kbGVDbG9zZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/RandomProducts.js\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap/dist/css/bootstrap.min.css */ \"./node_modules/bootstrap/dist/css/bootstrap.min.css\");\n/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Layout */ \"./components/Layout.js\");\n/********************************************************************************\n*  WEB422 – Assignment 3\n*  \n*  I declare that this assignment is my own work in accordance with Seneca's \n*  Academic Integrity Policy: \n*  \n*  https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html \n*  \n*  Name: Christopher Simon   Student ID: 123382228   Date: June 22nd, 2024\n*\n********************************************************************************/ \n\n\nfunction MyApp({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\pages\\\\_app.js\",\n            lineNumber: 20,\n            columnNumber: 13\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\pages\\\\_app.js\",\n        lineNumber: 19,\n        columnNumber: 9\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBOzs7Ozs7Ozs7OytFQVUrRTtBQUdqQztBQUNKO0FBRTFDLFNBQVNDLE1BQU0sRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDbkMscUJBQ0ksOERBQUNILDBEQUFNQTtrQkFDSCw0RUFBQ0U7WUFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7OztBQUdwQztBQUVBLGlFQUFlRixLQUFLQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2ViNDIyX2Fzc2lnbm1lbnRfMy8uL3BhZ2VzL19hcHAuanM/ZTBhZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiogIFdFQjQyMiDigJMgQXNzaWdubWVudCAzXG4qICBcbiogIEkgZGVjbGFyZSB0aGF0IHRoaXMgYXNzaWdubWVudCBpcyBteSBvd24gd29yayBpbiBhY2NvcmRhbmNlIHdpdGggU2VuZWNhJ3MgXG4qICBBY2FkZW1pYyBJbnRlZ3JpdHkgUG9saWN5OiBcbiogIFxuKiAgaHR0cHM6Ly93d3cuc2VuZWNhcG9seXRlY2huaWMuY2EvYWJvdXQvcG9saWNpZXMvYWNhZGVtaWMtaW50ZWdyaXR5LXBvbGljeS5odG1sIFxuKiAgXG4qICBOYW1lOiBDaHJpc3RvcGhlciBTaW1vbiAgIFN0dWRlbnQgSUQ6IDEyMzM4MjIyOCAgIERhdGU6IEp1bmUgMjJuZCwgMjAyNFxuKlxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cblxuaW1wb3J0ICdib290c3RyYXAvZGlzdC9jc3MvYm9vdHN0cmFwLm1pbi5jc3MnO1xuaW1wb3J0IExheW91dCBmcm9tICcuLi9jb21wb25lbnRzL0xheW91dCc7XG5cbmZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICAgIHJldHVybiAoXG4gICAgICAgIDxMYXlvdXQ+XG4gICAgICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgICAgIDwvTGF5b3V0PlxuICAgICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IE15QXBwO1xuIl0sIm5hbWVzIjpbIkxheW91dCIsIk15QXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./pages/_document.js":
/*!****************************!*\
  !*** ./pages/_document.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Document)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/document */ \"./node_modules/next/document.js\");\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Document() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {\n        lang: \"en\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\pages\\\\_document.js\",\n                lineNumber: 6,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\pages\\\\_document.js\",\n                        lineNumber: 8,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\pages\\\\_document.js\",\n                        lineNumber: 9,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\pages\\\\_document.js\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\pages\\\\_document.js\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fZG9jdW1lbnQuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQTZEO0FBRTlDLFNBQVNJO0lBQ3RCLHFCQUNFLDhEQUFDSiwrQ0FBSUE7UUFBQ0ssTUFBSzs7MEJBQ1QsOERBQUNKLCtDQUFJQTs7Ozs7MEJBQ0wsOERBQUNLOztrQ0FDQyw4REFBQ0osK0NBQUlBOzs7OztrQ0FDTCw4REFBQ0MscURBQVVBOzs7Ozs7Ozs7Ozs7Ozs7OztBQUluQiIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYjQyMl9hc3NpZ25tZW50XzMvLi9wYWdlcy9fZG9jdW1lbnQuanM/NTM4YiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBIdG1sLCBIZWFkLCBNYWluLCBOZXh0U2NyaXB0IH0gZnJvbSBcIm5leHQvZG9jdW1lbnRcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRG9jdW1lbnQoKSB7XG4gIHJldHVybiAoXG4gICAgPEh0bWwgbGFuZz1cImVuXCI+XG4gICAgICA8SGVhZCAvPlxuICAgICAgPGJvZHk+XG4gICAgICAgIDxNYWluIC8+XG4gICAgICAgIDxOZXh0U2NyaXB0IC8+XG4gICAgICA8L2JvZHk+XG4gICAgPC9IdG1sPlxuICApO1xufVxuIl0sIm5hbWVzIjpbIkh0bWwiLCJIZWFkIiwiTWFpbiIsIk5leHRTY3JpcHQiLCJEb2N1bWVudCIsImxhbmciLCJib2R5Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_document.js\n");

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home),\n/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_Carousel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Carousel */ \"./components/Carousel.js\");\n/* harmony import */ var _components_Intro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Intro */ \"./components/Intro.js\");\n/* harmony import */ var _components_Intro2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Intro2 */ \"./components/Intro2.js\");\n/* harmony import */ var _components_RandomProducts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/RandomProducts */ \"./components/RandomProducts.js\");\n/********************************************************************************\n*  WEB422 – Assignment 3\n*  \n*  I declare that this assignment is my own work in accordance with Seneca's \n*  Academic Integrity Policy: \n*  \n*  https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html \n*  \n*  Name: Christopher Simon   Student ID: 123382228   Date: June 22nd, 2024\n*\n********************************************************************************/ \n\n\n\n\nfunction Home({ products }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Intro__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\pages\\\\index.js\",\n                lineNumber: 21,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Carousel__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n                products: products\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\pages\\\\index.js\",\n                lineNumber: 22,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Intro2__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\pages\\\\index.js\",\n                lineNumber: 23,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_RandomProducts__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\pages\\\\index.js\",\n                lineNumber: 24,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\Dev Environment\\\\web422_assignment_3\\\\pages\\\\index.js\",\n        lineNumber: 20,\n        columnNumber: 9\n    }, this);\n}\nasync function getServerSideProps() {\n    const res = await fetch(\"https://fakestoreapi.com/products\");\n    const products = await res.json();\n    return {\n        props: {\n            products\n        }\n    };\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFBOzs7Ozs7Ozs7OytFQVUrRTtBQUUxQjtBQUNiO0FBQ0U7QUFDZ0I7QUFFM0MsU0FBU0ksS0FBSyxFQUFFQyxRQUFRLEVBQUU7SUFDckMscUJBQ0ksOERBQUNDOzswQkFDRyw4REFBQ0wseURBQUtBOzs7OzswQkFDTiw4REFBQ0QsNERBQWVBO2dCQUFDSyxVQUFVQTs7Ozs7OzBCQUMzQiw4REFBQ0gsMERBQU1BOzs7OzswQkFDUCw4REFBQ0Msa0VBQWNBOzs7Ozs7Ozs7OztBQUczQjtBQUVPLGVBQWVJO0lBQ2xCLE1BQU1DLE1BQU0sTUFBTUMsTUFBTTtJQUN4QixNQUFNSixXQUFXLE1BQU1HLElBQUlFLElBQUk7SUFFL0IsT0FBTztRQUNIQyxPQUFPO1lBQ0hOO1FBQ0o7SUFDSjtBQUNKIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2ViNDIyX2Fzc2lnbm1lbnRfMy8uL3BhZ2VzL2luZGV4LmpzP2JlZTciXSwic291cmNlc0NvbnRlbnQiOlsiLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4qICBXRUI0MjIg4oCTIEFzc2lnbm1lbnQgM1xuKiAgXG4qICBJIGRlY2xhcmUgdGhhdCB0aGlzIGFzc2lnbm1lbnQgaXMgbXkgb3duIHdvcmsgaW4gYWNjb3JkYW5jZSB3aXRoIFNlbmVjYSdzIFxuKiAgQWNhZGVtaWMgSW50ZWdyaXR5IFBvbGljeTogXG4qICBcbiogIGh0dHBzOi8vd3d3LnNlbmVjYXBvbHl0ZWNobmljLmNhL2Fib3V0L3BvbGljaWVzL2FjYWRlbWljLWludGVncml0eS1wb2xpY3kuaHRtbCBcbiogIFxuKiAgTmFtZTogQ2hyaXN0b3BoZXIgU2ltb24gICBTdHVkZW50IElEOiAxMjMzODIyMjggICBEYXRlOiBKdW5lIDIybmQsIDIwMjRcbipcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG5pbXBvcnQgUHJvZHVjdENhcm91c2VsIGZyb20gJy4uL2NvbXBvbmVudHMvQ2Fyb3VzZWwnO1xuaW1wb3J0IEludHJvIGZyb20gJy4uL2NvbXBvbmVudHMvSW50cm8nO1xuaW1wb3J0IEludHJvMiBmcm9tICcuLi9jb21wb25lbnRzL0ludHJvMic7XG5pbXBvcnQgUmFuZG9tUHJvZHVjdHMgZnJvbSAnLi4vY29tcG9uZW50cy9SYW5kb21Qcm9kdWN0cyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoeyBwcm9kdWN0cyB9KSB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxJbnRybyAvPlxuICAgICAgICAgICAgPFByb2R1Y3RDYXJvdXNlbCBwcm9kdWN0cz17cHJvZHVjdHN9IC8+XG4gICAgICAgICAgICA8SW50cm8yIC8+XG4gICAgICAgICAgICA8UmFuZG9tUHJvZHVjdHMgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcnZlclNpZGVQcm9wcygpIHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCgnaHR0cHM6Ly9mYWtlc3RvcmVhcGkuY29tL3Byb2R1Y3RzJyk7XG4gICAgY29uc3QgcHJvZHVjdHMgPSBhd2FpdCByZXMuanNvbigpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgcHJvcHM6IHtcbiAgICAgICAgICAgIHByb2R1Y3RzLFxuICAgICAgICB9LFxuICAgIH07XG59XG4iXSwibmFtZXMiOlsiUHJvZHVjdENhcm91c2VsIiwiSW50cm8iLCJJbnRybzIiLCJSYW5kb21Qcm9kdWN0cyIsIkhvbWUiLCJwcm9kdWN0cyIsImRpdiIsImdldFNlcnZlclNpZGVQcm9wcyIsInJlcyIsImZldGNoIiwianNvbiIsInByb3BzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/index.js\n");

/***/ }),

/***/ "@restart/hooks/useBreakpoint":
/*!***********************************************!*\
  !*** external "@restart/hooks/useBreakpoint" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useBreakpoint");

/***/ }),

/***/ "@restart/hooks/useCallbackRef":
/*!************************************************!*\
  !*** external "@restart/hooks/useCallbackRef" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useCallbackRef");

/***/ }),

/***/ "@restart/hooks/useCommittedRef":
/*!*************************************************!*\
  !*** external "@restart/hooks/useCommittedRef" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useCommittedRef");

/***/ }),

/***/ "@restart/hooks/useEventCallback":
/*!**************************************************!*\
  !*** external "@restart/hooks/useEventCallback" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useEventCallback");

/***/ }),

/***/ "@restart/hooks/useMergedRefs":
/*!***********************************************!*\
  !*** external "@restart/hooks/useMergedRefs" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useMergedRefs");

/***/ }),

/***/ "@restart/hooks/useTimeout":
/*!********************************************!*\
  !*** external "@restart/hooks/useTimeout" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useTimeout");

/***/ }),

/***/ "@restart/hooks/useUpdateEffect":
/*!*************************************************!*\
  !*** external "@restart/hooks/useUpdateEffect" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useUpdateEffect");

/***/ }),

/***/ "@restart/hooks/useWillUnmount":
/*!************************************************!*\
  !*** external "@restart/hooks/useWillUnmount" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useWillUnmount");

/***/ }),

/***/ "@restart/ui/Anchor":
/*!*************************************!*\
  !*** external "@restart/ui/Anchor" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Anchor");

/***/ }),

/***/ "@restart/ui/Button":
/*!*************************************!*\
  !*** external "@restart/ui/Button" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Button");

/***/ }),

/***/ "@restart/ui/Modal":
/*!************************************!*\
  !*** external "@restart/ui/Modal" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Modal");

/***/ }),

/***/ "@restart/ui/ModalManager":
/*!*******************************************!*\
  !*** external "@restart/ui/ModalManager" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/ModalManager");

/***/ }),

/***/ "@restart/ui/Nav":
/*!**********************************!*\
  !*** external "@restart/ui/Nav" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Nav");

/***/ }),

/***/ "@restart/ui/NavItem":
/*!**************************************!*\
  !*** external "@restart/ui/NavItem" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/NavItem");

/***/ }),

/***/ "@restart/ui/SelectableContext":
/*!************************************************!*\
  !*** external "@restart/ui/SelectableContext" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/SelectableContext");

/***/ }),

/***/ "classnames":
/*!*****************************!*\
  !*** external "classnames" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ "dom-helpers/addClass":
/*!***************************************!*\
  !*** external "dom-helpers/addClass" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/addClass");

/***/ }),

/***/ "dom-helpers/addEventListener":
/*!***********************************************!*\
  !*** external "dom-helpers/addEventListener" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/addEventListener");

/***/ }),

/***/ "dom-helpers/canUseDOM":
/*!****************************************!*\
  !*** external "dom-helpers/canUseDOM" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/canUseDOM");

/***/ }),

/***/ "dom-helpers/css":
/*!**********************************!*\
  !*** external "dom-helpers/css" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/css");

/***/ }),

/***/ "dom-helpers/ownerDocument":
/*!********************************************!*\
  !*** external "dom-helpers/ownerDocument" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/ownerDocument");

/***/ }),

/***/ "dom-helpers/querySelectorAll":
/*!***********************************************!*\
  !*** external "dom-helpers/querySelectorAll" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/querySelectorAll");

/***/ }),

/***/ "dom-helpers/removeClass":
/*!******************************************!*\
  !*** external "dom-helpers/removeClass" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/removeClass");

/***/ }),

/***/ "dom-helpers/removeEventListener":
/*!**************************************************!*\
  !*** external "dom-helpers/removeEventListener" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/removeEventListener");

/***/ }),

/***/ "dom-helpers/scrollbarSize":
/*!********************************************!*\
  !*** external "dom-helpers/scrollbarSize" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/scrollbarSize");

/***/ }),

/***/ "dom-helpers/transitionEnd":
/*!********************************************!*\
  !*** external "dom-helpers/transitionEnd" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/transitionEnd");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types");

/***/ }),

/***/ "prop-types-extra/lib/all":
/*!*******************************************!*\
  !*** external "prop-types-extra/lib/all" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types-extra/lib/all");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-transition-group/Transition":
/*!****************************************************!*\
  !*** external "react-transition-group/Transition" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-transition-group/Transition");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "uncontrollable":
/*!*********************************!*\
  !*** external "uncontrollable" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("uncontrollable");

/***/ }),

/***/ "warning":
/*!**************************!*\
  !*** external "warning" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("warning");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/react-bootstrap","vendor-chunks/bootstrap"], () => (__webpack_exec__("./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();
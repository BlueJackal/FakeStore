"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "__barrel_optimize__?names=Button,Container,Form,FormControl,Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js":
/*!****************************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Button,Container,Form,FormControl,Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js ***!
  \****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Button: () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Container: () => (/* reexport safe */ _Container__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Form: () => (/* reexport safe */ _Form__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   FormControl: () => (/* reexport safe */ _FormControl__WEBPACK_IMPORTED_MODULE_3__[\"default\"]),\n/* harmony export */   Nav: () => (/* reexport safe */ _Nav__WEBPACK_IMPORTED_MODULE_4__[\"default\"]),\n/* harmony export */   Navbar: () => (/* reexport safe */ _Navbar__WEBPACK_IMPORTED_MODULE_5__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ \"./node_modules/react-bootstrap/esm/Button.js\");\n/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Container */ \"./node_modules/react-bootstrap/esm/Container.js\");\n/* harmony import */ var _Form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Form */ \"./node_modules/react-bootstrap/esm/Form.js\");\n/* harmony import */ var _FormControl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./FormControl */ \"./node_modules/react-bootstrap/esm/FormControl.js\");\n/* harmony import */ var _Nav__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Nav */ \"./node_modules/react-bootstrap/esm/Nav.js\");\n/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Navbar */ \"./node_modules/react-bootstrap/esm/Navbar.js\");\n\n\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1CdXR0b24sQ29udGFpbmVyLEZvcm0sRm9ybUNvbnRyb2wsTmF2LE5hdmJhciE9IS4vbm9kZV9tb2R1bGVzL3JlYWN0LWJvb3RzdHJhcC9lc20vaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUM0QztBQUNNO0FBQ1Y7QUFDYztBQUNoQiIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYjQyMl9hc3NpZ25tZW50XzMvLi9ub2RlX21vZHVsZXMvcmVhY3QtYm9vdHN0cmFwL2VzbS9pbmRleC5qcz82NTZhIl0sInNvdXJjZXNDb250ZW50IjpbIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBCdXR0b24gfSBmcm9tIFwiLi9CdXR0b25cIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBDb250YWluZXIgfSBmcm9tIFwiLi9Db250YWluZXJcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBGb3JtIH0gZnJvbSBcIi4vRm9ybVwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEZvcm1Db250cm9sIH0gZnJvbSBcIi4vRm9ybUNvbnRyb2xcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBOYXYgfSBmcm9tIFwiLi9OYXZcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBOYXZiYXIgfSBmcm9tIFwiLi9OYXZiYXJcIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Button,Container,Form,FormControl,Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Button,ListGroup,Modal!=!./node_modules/react-bootstrap/esm/index.js":
/*!******************************************************************************************************!*\
  !*** __barrel_optimize__?names=Button,ListGroup,Modal!=!./node_modules/react-bootstrap/esm/index.js ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Button: () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   ListGroup: () => (/* reexport safe */ _ListGroup__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Modal: () => (/* reexport safe */ _Modal__WEBPACK_IMPORTED_MODULE_2__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ \"./node_modules/react-bootstrap/esm/Button.js\");\n/* harmony import */ var _ListGroup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ListGroup */ \"./node_modules/react-bootstrap/esm/ListGroup.js\");\n/* harmony import */ var _Modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Modal */ \"./node_modules/react-bootstrap/esm/Modal.js\");\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1CdXR0b24sTGlzdEdyb3VwLE1vZGFsIT0hLi9ub2RlX21vZHVsZXMvcmVhY3QtYm9vdHN0cmFwL2VzbS9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQzRDO0FBQ00iLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly93ZWI0MjJfYXNzaWdubWVudF8zLy4vbm9kZV9tb2R1bGVzL3JlYWN0LWJvb3RzdHJhcC9lc20vaW5kZXguanM/NGQwMyJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQnV0dG9uIH0gZnJvbSBcIi4vQnV0dG9uXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTGlzdEdyb3VwIH0gZnJvbSBcIi4vTGlzdEdyb3VwXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTW9kYWwgfSBmcm9tIFwiLi9Nb2RhbFwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Button,ListGroup,Modal!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "./components/CartModal.js":
/*!*********************************!*\
  !*** ./components/CartModal.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ CartModal)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Button_ListGroup_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Button,ListGroup,Modal!=!react-bootstrap */ \"__barrel_optimize__?names=Button,ListGroup,Modal!=!./node_modules/react-bootstrap/esm/index.js\");\n/* harmony import */ var _contexts_CartContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../contexts/CartContext */ \"./contexts/CartContext.js\");\n\n\n\nfunction CartModal({ show, onHide }) {\n    const { cart, removeFromCart, clearCart } = (0,_contexts_CartContext__WEBPACK_IMPORTED_MODULE_1__.useCart)();\n    const totalPrice = cart.reduce((acc, item)=>acc + item.price * item.quantity, 0);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_ListGroup_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Modal, {\n        show: show,\n        onHide: onHide,\n        centered: true,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_ListGroup_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Modal.Header, {\n                closeButton: true,\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_ListGroup_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Modal.Title, {\n                    children: \"Shopping Cart\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                    lineNumber: 12,\n                    columnNumber: 17\n                }, this)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                lineNumber: 11,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_ListGroup_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Modal.Body, {\n                children: [\n                    cart.length === 0 ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                        children: \"Your cart is empty.\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                        lineNumber: 16,\n                        columnNumber: 21\n                    }, this) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_ListGroup_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.ListGroup, {\n                        children: cart.map((item)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_ListGroup_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.ListGroup.Item, {\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                    className: \"d-flex justify-content-between\",\n                                    children: [\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                            children: [\n                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h5\", {\n                                                    children: item.title\n                                                }, void 0, false, {\n                                                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                                                    lineNumber: 23,\n                                                    columnNumber: 41\n                                                }, this),\n                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                                    children: [\n                                                        \"Price: $\",\n                                                        item.price\n                                                    ]\n                                                }, void 0, true, {\n                                                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                                                    lineNumber: 24,\n                                                    columnNumber: 41\n                                                }, this),\n                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                                    children: [\n                                                        \"Quantity: \",\n                                                        item.quantity\n                                                    ]\n                                                }, void 0, true, {\n                                                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                                                    lineNumber: 25,\n                                                    columnNumber: 41\n                                                }, this)\n                                            ]\n                                        }, void 0, true, {\n                                            fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                                            lineNumber: 22,\n                                            columnNumber: 37\n                                        }, this),\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_ListGroup_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Button, {\n                                            variant: \"danger\",\n                                            onClick: ()=>removeFromCart(item.id),\n                                            children: \"Remove\"\n                                        }, void 0, false, {\n                                            fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                                            lineNumber: 27,\n                                            columnNumber: 37\n                                        }, this)\n                                    ]\n                                }, void 0, true, {\n                                    fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                                    lineNumber: 21,\n                                    columnNumber: 33\n                                }, this)\n                            }, item.id, false, {\n                                fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                                lineNumber: 20,\n                                columnNumber: 29\n                            }, this))\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                        lineNumber: 18,\n                        columnNumber: 21\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"hr\", {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                        lineNumber: 35,\n                        columnNumber: 17\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h4\", {\n                        children: [\n                            \"Total: $\",\n                            totalPrice.toFixed(2)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                        lineNumber: 36,\n                        columnNumber: 17\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                lineNumber: 14,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_ListGroup_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Modal.Footer, {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_ListGroup_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Button, {\n                        variant: \"secondary\",\n                        onClick: onHide,\n                        children: \"Close\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                        lineNumber: 39,\n                        columnNumber: 17\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_ListGroup_Modal_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Button, {\n                        variant: \"success\",\n                        onClick: ()=>{\n                            alert(\"Payment received!\");\n                            clearCart();\n                            onHide();\n                        },\n                        children: \"Checkout\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                        lineNumber: 42,\n                        columnNumber: 17\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n                lineNumber: 38,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\CartModal.js\",\n        lineNumber: 10,\n        columnNumber: 9\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0NhcnRNb2RhbC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBMkQ7QUFDVDtBQUVuQyxTQUFTSSxVQUFVLEVBQUVDLElBQUksRUFBRUMsTUFBTSxFQUFFO0lBQzlDLE1BQU0sRUFBRUMsSUFBSSxFQUFFQyxjQUFjLEVBQUVDLFNBQVMsRUFBRSxHQUFHTiw4REFBT0E7SUFFbkQsTUFBTU8sYUFBYUgsS0FBS0ksTUFBTSxDQUFDLENBQUNDLEtBQUtDLE9BQVNELE1BQU1DLEtBQUtDLEtBQUssR0FBR0QsS0FBS0UsUUFBUSxFQUFFO0lBRWhGLHFCQUNJLDhEQUFDZixnR0FBS0E7UUFBQ0ssTUFBTUE7UUFBTUMsUUFBUUE7UUFBUVUsUUFBUTs7MEJBQ3ZDLDhEQUFDaEIsZ0dBQUtBLENBQUNpQixNQUFNO2dCQUFDQyxXQUFXOzBCQUNyQiw0RUFBQ2xCLGdHQUFLQSxDQUFDbUIsS0FBSzs4QkFBQzs7Ozs7Ozs7Ozs7MEJBRWpCLDhEQUFDbkIsZ0dBQUtBLENBQUNvQixJQUFJOztvQkFDTmIsS0FBS2MsTUFBTSxLQUFLLGtCQUNiLDhEQUFDQztrQ0FBRTs7Ozs7NkNBRUgsOERBQUNwQixvR0FBU0E7a0NBQ0xLLEtBQUtnQixHQUFHLENBQUMsQ0FBQ1YscUJBQ1AsOERBQUNYLG9HQUFTQSxDQUFDc0IsSUFBSTswQ0FDWCw0RUFBQ0M7b0NBQUlDLFdBQVU7O3NEQUNYLDhEQUFDRDs7OERBQ0csOERBQUNFOzhEQUFJZCxLQUFLZSxLQUFLOzs7Ozs7OERBQ2YsOERBQUNOOzt3REFBRTt3REFBU1QsS0FBS0MsS0FBSzs7Ozs7Ozs4REFDdEIsOERBQUNROzt3REFBRTt3REFBV1QsS0FBS0UsUUFBUTs7Ozs7Ozs7Ozs7OztzREFFL0IsOERBQUNkLGlHQUFNQTs0Q0FBQzRCLFNBQVE7NENBQVNDLFNBQVMsSUFBTXRCLGVBQWVLLEtBQUtrQixFQUFFO3NEQUFHOzs7Ozs7Ozs7Ozs7K0JBUHBEbEIsS0FBS2tCLEVBQUU7Ozs7Ozs7Ozs7a0NBZXhDLDhEQUFDQzs7Ozs7a0NBQ0QsOERBQUNDOzs0QkFBRzs0QkFBU3ZCLFdBQVd3QixPQUFPLENBQUM7Ozs7Ozs7Ozs7Ozs7MEJBRXBDLDhEQUFDbEMsZ0dBQUtBLENBQUNtQyxNQUFNOztrQ0FDVCw4REFBQ2xDLGlHQUFNQTt3QkFBQzRCLFNBQVE7d0JBQVlDLFNBQVN4QjtrQ0FBUTs7Ozs7O2tDQUc3Qyw4REFBQ0wsaUdBQU1BO3dCQUNINEIsU0FBUTt3QkFDUkMsU0FBUzs0QkFDTE0sTUFBTTs0QkFDTjNCOzRCQUNBSDt3QkFDSjtrQ0FDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBTWpCIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2ViNDIyX2Fzc2lnbm1lbnRfMy8uL2NvbXBvbmVudHMvQ2FydE1vZGFsLmpzPzkxNDIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9kYWwsIEJ1dHRvbiwgTGlzdEdyb3VwIH0gZnJvbSAncmVhY3QtYm9vdHN0cmFwJztcclxuaW1wb3J0IHsgdXNlQ2FydCB9IGZyb20gJy4uL2NvbnRleHRzL0NhcnRDb250ZXh0JztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENhcnRNb2RhbCh7IHNob3csIG9uSGlkZSB9KSB7XHJcbiAgICBjb25zdCB7IGNhcnQsIHJlbW92ZUZyb21DYXJ0LCBjbGVhckNhcnQgfSA9IHVzZUNhcnQoKTtcclxuXHJcbiAgICBjb25zdCB0b3RhbFByaWNlID0gY2FydC5yZWR1Y2UoKGFjYywgaXRlbSkgPT4gYWNjICsgaXRlbS5wcmljZSAqIGl0ZW0ucXVhbnRpdHksIDApO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPE1vZGFsIHNob3c9e3Nob3d9IG9uSGlkZT17b25IaWRlfSBjZW50ZXJlZD5cclxuICAgICAgICAgICAgPE1vZGFsLkhlYWRlciBjbG9zZUJ1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxNb2RhbC5UaXRsZT5TaG9wcGluZyBDYXJ0PC9Nb2RhbC5UaXRsZT5cclxuICAgICAgICAgICAgPC9Nb2RhbC5IZWFkZXI+XHJcbiAgICAgICAgICAgIDxNb2RhbC5Cb2R5PlxyXG4gICAgICAgICAgICAgICAge2NhcnQubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwPllvdXIgY2FydCBpcyBlbXB0eS48L3A+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxMaXN0R3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtjYXJ0Lm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpc3RHcm91cC5JdGVtIGtleT17aXRlbS5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNT57aXRlbS50aXRsZX08L2g1PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+UHJpY2U6ICR7aXRlbS5wcmljZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD5RdWFudGl0eToge2l0ZW0ucXVhbnRpdHl9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZGFuZ2VyXCIgb25DbGljaz17KCkgPT4gcmVtb3ZlRnJvbUNhcnQoaXRlbS5pZCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVtb3ZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaXN0R3JvdXAuSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9MaXN0R3JvdXA+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPGhyIC8+XHJcbiAgICAgICAgICAgICAgICA8aDQ+VG90YWw6ICR7dG90YWxQcmljZS50b0ZpeGVkKDIpfTwvaDQ+XHJcbiAgICAgICAgICAgIDwvTW9kYWwuQm9keT5cclxuICAgICAgICAgICAgPE1vZGFsLkZvb3Rlcj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInNlY29uZGFyeVwiIG9uQ2xpY2s9e29uSGlkZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2xvc2VcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzdWNjZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsZXJ0KCdQYXltZW50IHJlY2VpdmVkIScpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGVhckNhcnQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25IaWRlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBDaGVja291dFxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvTW9kYWwuRm9vdGVyPlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICApO1xyXG59Il0sIm5hbWVzIjpbIk1vZGFsIiwiQnV0dG9uIiwiTGlzdEdyb3VwIiwidXNlQ2FydCIsIkNhcnRNb2RhbCIsInNob3ciLCJvbkhpZGUiLCJjYXJ0IiwicmVtb3ZlRnJvbUNhcnQiLCJjbGVhckNhcnQiLCJ0b3RhbFByaWNlIiwicmVkdWNlIiwiYWNjIiwiaXRlbSIsInByaWNlIiwicXVhbnRpdHkiLCJjZW50ZXJlZCIsIkhlYWRlciIsImNsb3NlQnV0dG9uIiwiVGl0bGUiLCJCb2R5IiwibGVuZ3RoIiwicCIsIm1hcCIsIkl0ZW0iLCJkaXYiLCJjbGFzc05hbWUiLCJoNSIsInRpdGxlIiwidmFyaWFudCIsIm9uQ2xpY2siLCJpZCIsImhyIiwiaDQiLCJ0b0ZpeGVkIiwiRm9vdGVyIiwiYWxlcnQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/CartModal.js\n");

/***/ }),

/***/ "./components/Layout.js":
/*!******************************!*\
  !*** ./components/Layout.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Navbar */ \"./components/Navbar.js\");\n\n\nfunction Layout({ children }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Navbar__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Layout.js\",\n                lineNumber: 6,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n                children: children\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Layout.js\",\n                lineNumber: 7,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0xheW91dC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFvQztBQUVyQixTQUFTQyxPQUFPLEVBQUVDLFFBQVEsRUFBRTtJQUN2QyxxQkFDSTs7MEJBQ0ksOERBQUNGLCtDQUFZQTs7Ozs7MEJBQ2IsOERBQUNHOzBCQUFNRDs7Ozs7Ozs7QUFHbkIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly93ZWI0MjJfYXNzaWdubWVudF8zLy4vY29tcG9uZW50cy9MYXlvdXQuanM/NTE1YyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQ3VzdG9tTmF2YmFyIGZyb20gJy4vTmF2YmFyJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dCh7IGNoaWxkcmVuIH0pIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPEN1c3RvbU5hdmJhciAvPlxyXG4gICAgICAgICAgICA8bWFpbj57Y2hpbGRyZW59PC9tYWluPlxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufVxyXG4iXSwibmFtZXMiOlsiQ3VzdG9tTmF2YmFyIiwiTGF5b3V0IiwiY2hpbGRyZW4iLCJtYWluIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/Layout.js\n");

/***/ }),

/***/ "./components/Navbar.js":
/*!******************************!*\
  !*** ./components/Navbar.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ CustomNavbar)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Container,Form,FormControl,Nav,Navbar!=!react-bootstrap */ \"__barrel_optimize__?names=Button,Container,Form,FormControl,Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js\");\n/* harmony import */ var _contexts_CartContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../contexts/CartContext */ \"./contexts/CartContext.js\");\n/* harmony import */ var _CartModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./CartModal */ \"./components/CartModal.js\");\n\n\n\n\n\n\nfunction CustomNavbar() {\n    const [searchTerm, setSearchTerm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const { cart } = (0,_contexts_CartContext__WEBPACK_IMPORTED_MODULE_3__.useCart)();\n    const [showCart, setShowCart] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const handleSearch = (e)=>{\n        e.preventDefault();\n        router.push(`/products?search=${encodeURIComponent(searchTerm)}`);\n    };\n    const handleNavigation = (e, path)=>{\n        e.preventDefault();\n        router.push(path);\n    };\n    const handleCartClick = ()=>{\n        setShowCart(true);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.Navbar, {\n        bg: \"light\",\n        expand: \"lg\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.Container, {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.Navbar.Brand, {\n                        href: \"/\",\n                        onClick: (e)=>handleNavigation(e, \"/\"),\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n                                src: \"/img/header_logo.png\",\n                                width: \"30\",\n                                height: \"30\",\n                                className: \"d-inline-block align-top\",\n                                alt: \"Logo\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                                lineNumber: 31,\n                                columnNumber: 21\n                            }, this),\n                            \" \",\n                            \"Chris Simon - Web Assignment 3\"\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                        lineNumber: 30,\n                        columnNumber: 17\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.Navbar.Toggle, {\n                        \"aria-controls\": \"basic-navbar-nav\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                        lineNumber: 41,\n                        columnNumber: 17\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.Navbar.Collapse, {\n                        id: \"basic-navbar-nav\",\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.Nav, {\n                                className: \"me-auto\",\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.Nav.Link, {\n                                        href: \"/\",\n                                        onClick: (e)=>handleNavigation(e, \"/\"),\n                                        children: \"Home\"\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                                        lineNumber: 44,\n                                        columnNumber: 25\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.Nav.Link, {\n                                        href: \"/about\",\n                                        onClick: (e)=>handleNavigation(e, \"/about\"),\n                                        children: \"About\"\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                                        lineNumber: 45,\n                                        columnNumber: 25\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.Nav.Link, {\n                                        href: \"/products\",\n                                        onClick: (e)=>handleNavigation(e, \"/products\"),\n                                        children: \"Products\"\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                                        lineNumber: 46,\n                                        columnNumber: 25\n                                    }, this)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                                lineNumber: 43,\n                                columnNumber: 21\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.Form, {\n                                className: \"d-flex\",\n                                onSubmit: handleSearch,\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.FormControl, {\n                                        type: \"search\",\n                                        placeholder: \"Search Products\",\n                                        className: \"me-2\",\n                                        \"aria-label\": \"Search\",\n                                        value: searchTerm,\n                                        onChange: (e)=>setSearchTerm(e.target.value)\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                                        lineNumber: 49,\n                                        columnNumber: 25\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.Button, {\n                                        variant: \"outline-success\",\n                                        type: \"submit\",\n                                        children: \"Search\"\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                                        lineNumber: 57,\n                                        columnNumber: 25\n                                    }, this)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                                lineNumber: 48,\n                                columnNumber: 21\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_FormControl_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.Button, {\n                                variant: \"outline-primary\",\n                                onClick: handleCartClick,\n                                children: [\n                                    \"Cart (\",\n                                    cart.length,\n                                    \")\"\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                                lineNumber: 59,\n                                columnNumber: 21\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                        lineNumber: 42,\n                        columnNumber: 17\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                lineNumber: 29,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_CartModal__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {\n                show: showCart,\n                onHide: ()=>setShowCart(false)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n                lineNumber: 64,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\components\\\\Navbar.js\",\n        lineNumber: 28,\n        columnNumber: 9\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL05hdmJhci5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFpQztBQUNPO0FBQzRDO0FBQ2xDO0FBQ2Q7QUFFckIsU0FBU1U7SUFDcEIsTUFBTSxDQUFDQyxZQUFZQyxjQUFjLEdBQUdaLCtDQUFRQSxDQUFDO0lBQzdDLE1BQU1hLFNBQVNaLHNEQUFTQTtJQUN4QixNQUFNLEVBQUVhLElBQUksRUFBRSxHQUFHTiw4REFBT0E7SUFDeEIsTUFBTSxDQUFDTyxVQUFVQyxZQUFZLEdBQUdoQiwrQ0FBUUEsQ0FBQztJQUV6QyxNQUFNaUIsZUFBZSxDQUFDQztRQUNsQkEsRUFBRUMsY0FBYztRQUNoQk4sT0FBT08sSUFBSSxDQUFDLENBQUMsaUJBQWlCLEVBQUVDLG1CQUFtQlYsWUFBWSxDQUFDO0lBQ3BFO0lBRUEsTUFBTVcsbUJBQW1CLENBQUNKLEdBQUdLO1FBQ3pCTCxFQUFFQyxjQUFjO1FBQ2hCTixPQUFPTyxJQUFJLENBQUNHO0lBQ2hCO0lBRUEsTUFBTUMsa0JBQWtCO1FBQ3BCUixZQUFZO0lBQ2hCO0lBRUEscUJBQ0ksOERBQUNkLHVIQUFNQTtRQUFDdUIsSUFBRztRQUFRQyxRQUFPOzswQkFDdEIsOERBQUN0QiwwSEFBU0E7O2tDQUNOLDhEQUFDRix1SEFBTUEsQ0FBQ3lCLEtBQUs7d0JBQUNDLE1BQUs7d0JBQUlDLFNBQVMsQ0FBQ1gsSUFBTUksaUJBQWlCSixHQUFHOzswQ0FDdkQsOERBQUNZO2dDQUNHQyxLQUFJO2dDQUNKQyxPQUFNO2dDQUNOQyxRQUFPO2dDQUNQQyxXQUFVO2dDQUNWQyxLQUFJOzs7Ozs7NEJBRVA7NEJBQUk7Ozs7Ozs7a0NBR1QsOERBQUNqQyx1SEFBTUEsQ0FBQ2tDLE1BQU07d0JBQUNDLGlCQUFjOzs7Ozs7a0NBQzdCLDhEQUFDbkMsdUhBQU1BLENBQUNvQyxRQUFRO3dCQUFDQyxJQUFHOzswQ0FDaEIsOERBQUNwQyxvSEFBR0E7Z0NBQUMrQixXQUFVOztrREFDWCw4REFBQy9CLG9IQUFHQSxDQUFDcUMsSUFBSTt3Q0FBQ1osTUFBSzt3Q0FBSUMsU0FBUyxDQUFDWCxJQUFNSSxpQkFBaUJKLEdBQUc7a0RBQU07Ozs7OztrREFDN0QsOERBQUNmLG9IQUFHQSxDQUFDcUMsSUFBSTt3Q0FBQ1osTUFBSzt3Q0FBU0MsU0FBUyxDQUFDWCxJQUFNSSxpQkFBaUJKLEdBQUc7a0RBQVc7Ozs7OztrREFDdkUsOERBQUNmLG9IQUFHQSxDQUFDcUMsSUFBSTt3Q0FBQ1osTUFBSzt3Q0FBWUMsU0FBUyxDQUFDWCxJQUFNSSxpQkFBaUJKLEdBQUc7a0RBQWM7Ozs7Ozs7Ozs7OzswQ0FFakYsOERBQUNiLHFIQUFJQTtnQ0FBQzZCLFdBQVU7Z0NBQVNPLFVBQVV4Qjs7a0RBQy9CLDhEQUFDWCw0SEFBV0E7d0NBQ1JvQyxNQUFLO3dDQUNMQyxhQUFZO3dDQUNaVCxXQUFVO3dDQUNWVSxjQUFXO3dDQUNYQyxPQUFPbEM7d0NBQ1BtQyxVQUFVLENBQUM1QixJQUFNTixjQUFjTSxFQUFFNkIsTUFBTSxDQUFDRixLQUFLOzs7Ozs7a0RBRWpELDhEQUFDdEMsdUhBQU1BO3dDQUFDeUMsU0FBUTt3Q0FBa0JOLE1BQUs7a0RBQVM7Ozs7Ozs7Ozs7OzswQ0FFcEQsOERBQUNuQyx1SEFBTUE7Z0NBQUN5QyxTQUFRO2dDQUFrQm5CLFNBQVNMOztvQ0FBaUI7b0NBQ2pEVixLQUFLbUMsTUFBTTtvQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQkFJL0IsOERBQUN4QyxrREFBU0E7Z0JBQUN5QyxNQUFNbkM7Z0JBQVVvQyxRQUFRLElBQU1uQyxZQUFZOzs7Ozs7Ozs7Ozs7QUFHakUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly93ZWI0MjJfYXNzaWdubWVudF8zLy4vY29tcG9uZW50cy9OYXZiYXIuanM/ZmJjYSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInO1xyXG5pbXBvcnQgeyBOYXZiYXIsIE5hdiwgQ29udGFpbmVyLCBGb3JtLCBGb3JtQ29udHJvbCwgQnV0dG9uIH0gZnJvbSAncmVhY3QtYm9vdHN0cmFwJztcclxuaW1wb3J0IHsgdXNlQ2FydCB9IGZyb20gJy4uL2NvbnRleHRzL0NhcnRDb250ZXh0JztcclxuaW1wb3J0IENhcnRNb2RhbCBmcm9tICcuL0NhcnRNb2RhbCc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDdXN0b21OYXZiYXIoKSB7XHJcbiAgICBjb25zdCBbc2VhcmNoVGVybSwgc2V0U2VhcmNoVGVybV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICAgIGNvbnN0IHsgY2FydCB9ID0gdXNlQ2FydCgpO1xyXG4gICAgY29uc3QgW3Nob3dDYXJ0LCBzZXRTaG93Q2FydF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlU2VhcmNoID0gKGUpID0+IHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgcm91dGVyLnB1c2goYC9wcm9kdWN0cz9zZWFyY2g9JHtlbmNvZGVVUklDb21wb25lbnQoc2VhcmNoVGVybSl9YCk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZU5hdmlnYXRpb24gPSAoZSwgcGF0aCkgPT4ge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICByb3V0ZXIucHVzaChwYXRoKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQ2FydENsaWNrID0gKCkgPT4ge1xyXG4gICAgICAgIHNldFNob3dDYXJ0KHRydWUpO1xyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxOYXZiYXIgYmc9XCJsaWdodFwiIGV4cGFuZD1cImxnXCI+XHJcbiAgICAgICAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAgICAgICAgICA8TmF2YmFyLkJyYW5kIGhyZWY9XCIvXCIgb25DbGljaz17KGUpID0+IGhhbmRsZU5hdmlnYXRpb24oZSwgJy8nKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzcmM9XCIvaW1nL2hlYWRlcl9sb2dvLnBuZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoPVwiMzBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCIzMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImQtaW5saW5lLWJsb2NrIGFsaWduLXRvcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIkxvZ29cIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgeycgJ31cclxuICAgICAgICAgICAgICAgICAgICBDaHJpcyBTaW1vbiAtIFdlYiBBc3NpZ25tZW50IDNcclxuICAgICAgICAgICAgICAgIDwvTmF2YmFyLkJyYW5kPlxyXG4gICAgICAgICAgICAgICAgPE5hdmJhci5Ub2dnbGUgYXJpYS1jb250cm9scz1cImJhc2ljLW5hdmJhci1uYXZcIiAvPlxyXG4gICAgICAgICAgICAgICAgPE5hdmJhci5Db2xsYXBzZSBpZD1cImJhc2ljLW5hdmJhci1uYXZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8TmF2IGNsYXNzTmFtZT1cIm1lLWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPE5hdi5MaW5rIGhyZWY9XCIvXCIgb25DbGljaz17KGUpID0+IGhhbmRsZU5hdmlnYXRpb24oZSwgJy8nKX0+SG9tZTwvTmF2Lkxpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxOYXYuTGluayBocmVmPVwiL2Fib3V0XCIgb25DbGljaz17KGUpID0+IGhhbmRsZU5hdmlnYXRpb24oZSwgJy9hYm91dCcpfT5BYm91dDwvTmF2Lkxpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxOYXYuTGluayBocmVmPVwiL3Byb2R1Y3RzXCIgb25DbGljaz17KGUpID0+IGhhbmRsZU5hdmlnYXRpb24oZSwgJy9wcm9kdWN0cycpfT5Qcm9kdWN0czwvTmF2Lkxpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9OYXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZvcm0gY2xhc3NOYW1lPVwiZC1mbGV4XCIgb25TdWJtaXQ9e2hhbmRsZVNlYXJjaH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtQ29udHJvbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInNlYXJjaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBQcm9kdWN0c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtZS0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJTZWFyY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFRlcm19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFRlcm0oZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lLXN1Y2Nlc3NcIiB0eXBlPVwic3VibWl0XCI+U2VhcmNoPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Gb3JtPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmUtcHJpbWFyeVwiIG9uQ2xpY2s9e2hhbmRsZUNhcnRDbGlja30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENhcnQgKHtjYXJ0Lmxlbmd0aH0pXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L05hdmJhci5Db2xsYXBzZT5cclxuICAgICAgICAgICAgPC9Db250YWluZXI+XHJcbiAgICAgICAgICAgIDxDYXJ0TW9kYWwgc2hvdz17c2hvd0NhcnR9IG9uSGlkZT17KCkgPT4gc2V0U2hvd0NhcnQoZmFsc2UpfSAvPlxyXG4gICAgICAgIDwvTmF2YmFyPlxyXG4gICAgKTtcclxufSJdLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZVJvdXRlciIsIk5hdmJhciIsIk5hdiIsIkNvbnRhaW5lciIsIkZvcm0iLCJGb3JtQ29udHJvbCIsIkJ1dHRvbiIsInVzZUNhcnQiLCJDYXJ0TW9kYWwiLCJDdXN0b21OYXZiYXIiLCJzZWFyY2hUZXJtIiwic2V0U2VhcmNoVGVybSIsInJvdXRlciIsImNhcnQiLCJzaG93Q2FydCIsInNldFNob3dDYXJ0IiwiaGFuZGxlU2VhcmNoIiwiZSIsInByZXZlbnREZWZhdWx0IiwicHVzaCIsImVuY29kZVVSSUNvbXBvbmVudCIsImhhbmRsZU5hdmlnYXRpb24iLCJwYXRoIiwiaGFuZGxlQ2FydENsaWNrIiwiYmciLCJleHBhbmQiLCJCcmFuZCIsImhyZWYiLCJvbkNsaWNrIiwiaW1nIiwic3JjIiwid2lkdGgiLCJoZWlnaHQiLCJjbGFzc05hbWUiLCJhbHQiLCJUb2dnbGUiLCJhcmlhLWNvbnRyb2xzIiwiQ29sbGFwc2UiLCJpZCIsIkxpbmsiLCJvblN1Ym1pdCIsInR5cGUiLCJwbGFjZWhvbGRlciIsImFyaWEtbGFiZWwiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwidGFyZ2V0IiwidmFyaWFudCIsImxlbmd0aCIsInNob3ciLCJvbkhpZGUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/Navbar.js\n");

/***/ }),

/***/ "./contexts/CartContext.js":
/*!*********************************!*\
  !*** ./contexts/CartContext.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   CartProvider: () => (/* binding */ CartProvider),\n/* harmony export */   useCart: () => (/* binding */ useCart)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst CartContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();\nfunction useCart() {\n    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(CartContext);\n}\nfunction CartProvider({ children }) {\n    const [cart, setCart] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);\n    const addToCart = (product)=>{\n        setCart((prevCart)=>{\n            const existingProduct = prevCart.find((item)=>item.id === product.id);\n            if (existingProduct) {\n                return prevCart.map((item)=>item.id === product.id ? {\n                        ...item,\n                        quantity: item.quantity + 1\n                    } : item);\n            } else {\n                return [\n                    ...prevCart,\n                    {\n                        ...product,\n                        quantity: 1\n                    }\n                ];\n            }\n        });\n    };\n    const removeFromCart = (productId)=>{\n        setCart((prevCart)=>prevCart.filter((item)=>item.id !== productId));\n    };\n    const clearCart = ()=>{\n        setCart([]);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(CartContext.Provider, {\n        value: {\n            cart,\n            addToCart,\n            removeFromCart,\n            clearCart\n        },\n        children: children\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\contexts\\\\CartContext.js\",\n        lineNumber: 38,\n        columnNumber: 9\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb250ZXh0cy9DYXJ0Q29udGV4dC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQTREO0FBRTVELE1BQU1HLDRCQUFjSCxvREFBYUE7QUFFMUIsU0FBU0k7SUFDWixPQUFPSCxpREFBVUEsQ0FBQ0U7QUFDdEI7QUFFTyxTQUFTRSxhQUFhLEVBQUVDLFFBQVEsRUFBRTtJQUNyQyxNQUFNLENBQUNDLE1BQU1DLFFBQVEsR0FBR04sK0NBQVFBLENBQUMsRUFBRTtJQUVuQyxNQUFNTyxZQUFZLENBQUNDO1FBQ2ZGLFFBQVEsQ0FBQ0c7WUFDTCxNQUFNQyxrQkFBa0JELFNBQVNFLElBQUksQ0FBQyxDQUFDQyxPQUFTQSxLQUFLQyxFQUFFLEtBQUtMLFFBQVFLLEVBQUU7WUFDdEUsSUFBSUgsaUJBQWlCO2dCQUNqQixPQUFPRCxTQUFTSyxHQUFHLENBQUMsQ0FBQ0YsT0FDakJBLEtBQUtDLEVBQUUsS0FBS0wsUUFBUUssRUFBRSxHQUNoQjt3QkFBRSxHQUFHRCxJQUFJO3dCQUFFRyxVQUFVSCxLQUFLRyxRQUFRLEdBQUc7b0JBQUUsSUFDdkNIO1lBRWQsT0FBTztnQkFDSCxPQUFPO3VCQUFJSDtvQkFBVTt3QkFBRSxHQUFHRCxPQUFPO3dCQUFFTyxVQUFVO29CQUFFO2lCQUFFO1lBQ3JEO1FBQ0o7SUFDSjtJQUVBLE1BQU1DLGlCQUFpQixDQUFDQztRQUNwQlgsUUFBUSxDQUFDRyxXQUNMQSxTQUFTUyxNQUFNLENBQUMsQ0FBQ04sT0FBU0EsS0FBS0MsRUFBRSxLQUFLSTtJQUU5QztJQUVBLE1BQU1FLFlBQVk7UUFDZGIsUUFBUSxFQUFFO0lBQ2Q7SUFFQSxxQkFDSSw4REFBQ0wsWUFBWW1CLFFBQVE7UUFBQ0MsT0FBTztZQUFFaEI7WUFBTUU7WUFBV1M7WUFBZ0JHO1FBQVU7a0JBQ3JFZjs7Ozs7O0FBR2IiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly93ZWI0MjJfYXNzaWdubWVudF8zLy4vY29udGV4dHMvQ2FydENvbnRleHQuanM/ODRjYyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuXHJcbmNvbnN0IENhcnRDb250ZXh0ID0gY3JlYXRlQ29udGV4dCgpO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHVzZUNhcnQoKSB7XHJcbiAgICByZXR1cm4gdXNlQ29udGV4dChDYXJ0Q29udGV4dCk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBDYXJ0UHJvdmlkZXIoeyBjaGlsZHJlbiB9KSB7XHJcbiAgICBjb25zdCBbY2FydCwgc2V0Q2FydF0gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gICAgY29uc3QgYWRkVG9DYXJ0ID0gKHByb2R1Y3QpID0+IHtcclxuICAgICAgICBzZXRDYXJ0KChwcmV2Q2FydCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBleGlzdGluZ1Byb2R1Y3QgPSBwcmV2Q2FydC5maW5kKChpdGVtKSA9PiBpdGVtLmlkID09PSBwcm9kdWN0LmlkKTtcclxuICAgICAgICAgICAgaWYgKGV4aXN0aW5nUHJvZHVjdCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHByZXZDYXJ0Lm1hcCgoaXRlbSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBpdGVtLmlkID09PSBwcm9kdWN0LmlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8geyAuLi5pdGVtLCBxdWFudGl0eTogaXRlbS5xdWFudGl0eSArIDEgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IGl0ZW1cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gWy4uLnByZXZDYXJ0LCB7IC4uLnByb2R1Y3QsIHF1YW50aXR5OiAxIH1dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHJlbW92ZUZyb21DYXJ0ID0gKHByb2R1Y3RJZCkgPT4ge1xyXG4gICAgICAgIHNldENhcnQoKHByZXZDYXJ0KSA9PlxyXG4gICAgICAgICAgICBwcmV2Q2FydC5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uaWQgIT09IHByb2R1Y3RJZClcclxuICAgICAgICApO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBjbGVhckNhcnQgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0Q2FydChbXSk7XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPENhcnRDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IGNhcnQsIGFkZFRvQ2FydCwgcmVtb3ZlRnJvbUNhcnQsIGNsZWFyQ2FydCB9fT5cclxuICAgICAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICAgIDwvQ2FydENvbnRleHQuUHJvdmlkZXI+XHJcbiAgICApO1xyXG59Il0sIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VDb250ZXh0IiwidXNlU3RhdGUiLCJDYXJ0Q29udGV4dCIsInVzZUNhcnQiLCJDYXJ0UHJvdmlkZXIiLCJjaGlsZHJlbiIsImNhcnQiLCJzZXRDYXJ0IiwiYWRkVG9DYXJ0IiwicHJvZHVjdCIsInByZXZDYXJ0IiwiZXhpc3RpbmdQcm9kdWN0IiwiZmluZCIsIml0ZW0iLCJpZCIsIm1hcCIsInF1YW50aXR5IiwicmVtb3ZlRnJvbUNhcnQiLCJwcm9kdWN0SWQiLCJmaWx0ZXIiLCJjbGVhckNhcnQiLCJQcm92aWRlciIsInZhbHVlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./contexts/CartContext.js\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap/dist/css/bootstrap.min.css */ \"./node_modules/bootstrap/dist/css/bootstrap.min.css\");\n/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Layout */ \"./components/Layout.js\");\n/* harmony import */ var _contexts_CartContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../contexts/CartContext */ \"./contexts/CartContext.js\");\n/********************************************************************************\n*  WEB422 – Assignment 4\n*  \n*  I declare that this assignment is my own work in accordance with Seneca's \n*  Academic Integrity Policy: \n*  \n*  https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html \n*  `\n*  Name: Christopher Simon   Student ID: 123382228   Date: July 13th, 2024\n*\n********************************************************************************/ \n\n\n\nfunction MyApp({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_contexts_CartContext__WEBPACK_IMPORTED_MODULE_3__.CartProvider, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\pages\\\\_app.js\",\n                lineNumber: 22,\n                columnNumber: 17\n            }, this)\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\pages\\\\_app.js\",\n            lineNumber: 21,\n            columnNumber: 13\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Dev Environment\\\\Desktop\\\\Web a4\\\\pages\\\\_app.js\",\n        lineNumber: 20,\n        columnNumber: 9\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQTs7Ozs7Ozs7OzsrRUFVK0U7QUFHakM7QUFDSjtBQUNhO0FBRXZELFNBQVNFLE1BQU0sRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDbkMscUJBQ0ksOERBQUNILCtEQUFZQTtrQkFDVCw0RUFBQ0QsMERBQU1BO3NCQUNILDRFQUFDRztnQkFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7Ozs7Ozs7O0FBSXhDO0FBRUEsaUVBQWVGLEtBQUtBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly93ZWI0MjJfYXNzaWdubWVudF8zLy4vcGFnZXMvX2FwcC5qcz9lMGFkIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuKiAgV0VCNDIyIOKAkyBBc3NpZ25tZW50IDRcbiogIFxuKiAgSSBkZWNsYXJlIHRoYXQgdGhpcyBhc3NpZ25tZW50IGlzIG15IG93biB3b3JrIGluIGFjY29yZGFuY2Ugd2l0aCBTZW5lY2EncyBcbiogIEFjYWRlbWljIEludGVncml0eSBQb2xpY3k6IFxuKiAgXG4qICBodHRwczovL3d3dy5zZW5lY2Fwb2x5dGVjaG5pYy5jYS9hYm91dC9wb2xpY2llcy9hY2FkZW1pYy1pbnRlZ3JpdHktcG9saWN5Lmh0bWwgXG4qICBgXG4qICBOYW1lOiBDaHJpc3RvcGhlciBTaW1vbiAgIFN0dWRlbnQgSUQ6IDEyMzM4MjIyOCAgIERhdGU6IEp1bHkgMTN0aCwgMjAyNFxuKlxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cblxuaW1wb3J0ICdib290c3RyYXAvZGlzdC9jc3MvYm9vdHN0cmFwLm1pbi5jc3MnO1xuaW1wb3J0IExheW91dCBmcm9tICcuLi9jb21wb25lbnRzL0xheW91dCc7XG5pbXBvcnQgeyBDYXJ0UHJvdmlkZXIgfSBmcm9tICcuLi9jb250ZXh0cy9DYXJ0Q29udGV4dCc7XG5cbmZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICAgIHJldHVybiAoXG4gICAgICAgIDxDYXJ0UHJvdmlkZXI+XG4gICAgICAgICAgICA8TGF5b3V0PlxuICAgICAgICAgICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgICAgICAgIDwvTGF5b3V0PlxuICAgICAgICA8L0NhcnRQcm92aWRlcj5cbiAgICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBNeUFwcDtcbiJdLCJuYW1lcyI6WyJMYXlvdXQiLCJDYXJ0UHJvdmlkZXIiLCJNeUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "@restart/hooks/useBreakpoint":
/*!***********************************************!*\
  !*** external "@restart/hooks/useBreakpoint" ***!
  \***********************************************/
/***/ ((module) => {

module.exports = require("@restart/hooks/useBreakpoint");

/***/ }),

/***/ "@restart/hooks/useCallbackRef":
/*!************************************************!*\
  !*** external "@restart/hooks/useCallbackRef" ***!
  \************************************************/
/***/ ((module) => {

module.exports = require("@restart/hooks/useCallbackRef");

/***/ }),

/***/ "@restart/hooks/useEventCallback":
/*!**************************************************!*\
  !*** external "@restart/hooks/useEventCallback" ***!
  \**************************************************/
/***/ ((module) => {

module.exports = require("@restart/hooks/useEventCallback");

/***/ }),

/***/ "@restart/hooks/useMergedRefs":
/*!***********************************************!*\
  !*** external "@restart/hooks/useMergedRefs" ***!
  \***********************************************/
/***/ ((module) => {

module.exports = require("@restart/hooks/useMergedRefs");

/***/ }),

/***/ "@restart/hooks/useWillUnmount":
/*!************************************************!*\
  !*** external "@restart/hooks/useWillUnmount" ***!
  \************************************************/
/***/ ((module) => {

module.exports = require("@restart/hooks/useWillUnmount");

/***/ }),

/***/ "@restart/ui/Anchor":
/*!*************************************!*\
  !*** external "@restart/ui/Anchor" ***!
  \*************************************/
/***/ ((module) => {

module.exports = require("@restart/ui/Anchor");

/***/ }),

/***/ "@restart/ui/Button":
/*!*************************************!*\
  !*** external "@restart/ui/Button" ***!
  \*************************************/
/***/ ((module) => {

module.exports = require("@restart/ui/Button");

/***/ }),

/***/ "@restart/ui/Modal":
/*!************************************!*\
  !*** external "@restart/ui/Modal" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("@restart/ui/Modal");

/***/ }),

/***/ "@restart/ui/ModalManager":
/*!*******************************************!*\
  !*** external "@restart/ui/ModalManager" ***!
  \*******************************************/
/***/ ((module) => {

module.exports = require("@restart/ui/ModalManager");

/***/ }),

/***/ "@restart/ui/Nav":
/*!**********************************!*\
  !*** external "@restart/ui/Nav" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("@restart/ui/Nav");

/***/ }),

/***/ "@restart/ui/NavItem":
/*!**************************************!*\
  !*** external "@restart/ui/NavItem" ***!
  \**************************************/
/***/ ((module) => {

module.exports = require("@restart/ui/NavItem");

/***/ }),

/***/ "@restart/ui/SelectableContext":
/*!************************************************!*\
  !*** external "@restart/ui/SelectableContext" ***!
  \************************************************/
/***/ ((module) => {

module.exports = require("@restart/ui/SelectableContext");

/***/ }),

/***/ "classnames":
/*!*****************************!*\
  !*** external "classnames" ***!
  \*****************************/
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ "dom-helpers/addClass":
/*!***************************************!*\
  !*** external "dom-helpers/addClass" ***!
  \***************************************/
/***/ ((module) => {

module.exports = require("dom-helpers/addClass");

/***/ }),

/***/ "dom-helpers/addEventListener":
/*!***********************************************!*\
  !*** external "dom-helpers/addEventListener" ***!
  \***********************************************/
/***/ ((module) => {

module.exports = require("dom-helpers/addEventListener");

/***/ }),

/***/ "dom-helpers/canUseDOM":
/*!****************************************!*\
  !*** external "dom-helpers/canUseDOM" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("dom-helpers/canUseDOM");

/***/ }),

/***/ "dom-helpers/css":
/*!**********************************!*\
  !*** external "dom-helpers/css" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("dom-helpers/css");

/***/ }),

/***/ "dom-helpers/ownerDocument":
/*!********************************************!*\
  !*** external "dom-helpers/ownerDocument" ***!
  \********************************************/
/***/ ((module) => {

module.exports = require("dom-helpers/ownerDocument");

/***/ }),

/***/ "dom-helpers/querySelectorAll":
/*!***********************************************!*\
  !*** external "dom-helpers/querySelectorAll" ***!
  \***********************************************/
/***/ ((module) => {

module.exports = require("dom-helpers/querySelectorAll");

/***/ }),

/***/ "dom-helpers/removeClass":
/*!******************************************!*\
  !*** external "dom-helpers/removeClass" ***!
  \******************************************/
/***/ ((module) => {

module.exports = require("dom-helpers/removeClass");

/***/ }),

/***/ "dom-helpers/removeEventListener":
/*!**************************************************!*\
  !*** external "dom-helpers/removeEventListener" ***!
  \**************************************************/
/***/ ((module) => {

module.exports = require("dom-helpers/removeEventListener");

/***/ }),

/***/ "dom-helpers/scrollbarSize":
/*!********************************************!*\
  !*** external "dom-helpers/scrollbarSize" ***!
  \********************************************/
/***/ ((module) => {

module.exports = require("dom-helpers/scrollbarSize");

/***/ }),

/***/ "dom-helpers/transitionEnd":
/*!********************************************!*\
  !*** external "dom-helpers/transitionEnd" ***!
  \********************************************/
/***/ ((module) => {

module.exports = require("dom-helpers/transitionEnd");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ "prop-types-extra/lib/all":
/*!*******************************************!*\
  !*** external "prop-types-extra/lib/all" ***!
  \*******************************************/
/***/ ((module) => {

module.exports = require("prop-types-extra/lib/all");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ "react-transition-group/Transition":
/*!****************************************************!*\
  !*** external "react-transition-group/Transition" ***!
  \****************************************************/
/***/ ((module) => {

module.exports = require("react-transition-group/Transition");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "uncontrollable":
/*!*********************************!*\
  !*** external "uncontrollable" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("uncontrollable");

/***/ }),

/***/ "warning":
/*!**************************!*\
  !*** external "warning" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("warning");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/react-bootstrap","vendor-chunks/bootstrap"], () => (__webpack_exec__("./pages/_app.js")));
module.exports = __webpack_exports__;

})();